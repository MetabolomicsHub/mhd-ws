import datetime
import hashlib
from logging import getLogger
from typing import Annotated

import jwt
from fastapi import Depends, Header
from fastapi.openapi.models import Example
from mxd.presentation.rest_api.groups.mxd.v1.model.mxd import (
    ApiToken,
    ApiTokenStatus,
    Repository,
    RepositoryStatus,
)
from mxd.presentation.rest_api.groups.mxd.v1.routers.db import get_db
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

logger = getLogger(__name__)


class RepositoryModel(BaseModel):
    id: Annotated[int, Field(title="Repository ID", description="Repository ID")]
    name: Annotated[str, Field(title="Repository Name", description="Repository name")]
    description: Annotated[
        None | str,
        Field(title="Repository description", description="Repository description"),
    ] = None
    join_datetime: Annotated[
        datetime.datetime, Field(title="Repository join date", description="join date")
    ]
    status: Annotated[
        RepositoryStatus,
        Field(title="Repository status", description="Repository status"),
    ]
    public_key: Annotated[
        None | str, Field(title="Repository public key", description="Repository key")
    ] = None


class RepositoryValidation(BaseModel):
    repository: Annotated[
        None | RepositoryModel,
        Field(
            title="Repository Name",
            description="Repository name stored on MetabolomeXchange database.",
        ),
    ] = None
    message: Annotated[
        None | str,
        Field(
            title="Validation message",
            description="Validation message. If the repository token is valid, this will be empty.",
        ),
    ] = None


VALIDATED_AUDIANCE = "https://www.metabolomexchange.org"


async def validate_api_token(
    api_token: Annotated[
        str,
        Header(
            title="API token.",
            description="Repository API token",
            alias="x-api-token",
        ),
    ],
    session: AsyncSession = Depends(get_db),
) -> RepositoryModel | None:
    token_hash = hashlib.sha256(api_token.encode()).hexdigest()
    async with session:
        stmt = (
            select(ApiToken)
            .where(
                ApiToken.token_hash == token_hash,
                ApiToken.status == ApiTokenStatus.VALID,
            )
            .options(selectinload(ApiToken.repository))
            .limit(1)
        )
        result = await session.execute(stmt)
        token = result.scalar_one_or_none()
        if not token:
            logger.error("API token not found or not valid.")
            return None
        repository = RepositoryModel.model_validate(
            token.repository, from_attributes=True
        )
        logger.info(f"{repository.name} token validated.")
        return repository


signed_jwt_token_description = """
Repository public key will be stored on MetabolomeXchange database and signed 
JWT token will be used to validate repository.
The repository application should create a JWT token and sign its payload using the repository private key.

JWT token structure:
- Header
    + Fields
    
        * alg: (Algorithm) payload signing algorithm. It must be "RS256" (RSA Signature with SHA-256)
        * typ: (Type) type of token. It must be "JWT"
    + Example:
    
        {
            "alg": "RS256",
            "typ": "JWT"
        }
- Payload
    * Payload should contain the following fields:
    
        + sub: (Subject) repository name defined in MetabolomeXchange database. 
                It is case sensitive string (e.g., MetaboLights, Metabolomics Workbench, GNPS, etc.)
        + aud: (Audience) MetabolomeXchange portal URL (Valid value: https://www.metabolomexchage.org)
        + iat: (Issued At) Issued time in seconds since the Epoch (IEEE Std 1003.1, 2013 Edition)
        + exp: (Expiration Time) Seconds Since the Epoch (IEEE Std 1003.1, 2013 Edition)
Example:
{
    "sub": <repository name>,
    "aud": "www.metabolomexchange.org",
    "iat": 1678886500,
    "exp": 1678972900
}
- Signature
    * Signature signed by the repository private key using RS256
"""


signed_jwt_token_header = Header(
    title="JWT token signed by the repository",
    description=signed_jwt_token_description,
    openapi_examples={
        "New Token": Example(
            summary="New Signed JWT Token",
            value="",
        ),
        "Test Signed JWT Token": Example(
            summary="Test Signed JWT Token",
            value="eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJNZXRhYm9MaWdodHMiLCJhdWQiOiJodHRwczovL3d3dy5tZXRhYm9sb21leGNoYW5nZS5vcmciLCJpYXQiOjE2OTk4ODY1MDAsImV4cCI6MTg5OTk3MjkwMH0.ILowqqd6xdtiY9RCNCLluOoJW46s516Q2hrGtqNziVfUIhfM0NpXZdscd6mtSGai6w8Ds3ZN62aMntx25Rx05vmUmjWVH2bZSiAmPlerwK5cqPI-wQ8SSAeB2Bo1VMXh3up55J-RbUT8XZE1jM0e_pzH-dkMQx_-nnjVEh1o3NDHBO5QvfFQq4XIU-1OtThxhSWYcBOb1K09KiiERmCok0AYkDOqfynbIcJv-K57ta8Xnry2HhsJKPHSGNUI_zjVMYGL44qR80_wTWQBNAlBe8IZteTn25ycDXadcIJcvPIdtuBhbt3MdJ7aaG4CzC8_uFXo-BYSBhYzeg",
        ),
    },
    alias="x_signed_jwt_token",
)


async def validate_repository_token(
    signed_jwt_token: Annotated[str, signed_jwt_token_header],
    session: AsyncSession = Depends(get_db),
) -> None | RepositoryValidation:
    token = signed_jwt_token
    options = {"require": ["exp", "sub", "iat", "sub"]}
    message = None
    repository_model = None
    try:
        decoded: dict[str, str] = jwt.decode(
            token, "", options={"verify_signature": False}
        )
        sub = decoded.get("sub")

        if sub:
            async with session:
                stmt = select(Repository).where(
                    Repository.name == sub, Repository.status == RepositoryStatus.ACTIVE
                )
                result = await session.execute(stmt)
                repo = result.scalar_one_or_none()
                if not repo:
                    message = f"Repository '{sub}' is not found or not active."
                    logger.error(message)
                else:
                    public_key = repo.public_key
                    if public_key:
                        decoded = jwt.decode(
                            jwt=token,
                            key=public_key,
                            options=options,
                            audience=VALIDATED_AUDIANCE,
                            algorithms=["RS256"],
                        )
                        logger.info(f"{repo.name} signed JWT token is validated.")
                        repository_model = RepositoryModel.model_validate(
                            repo, from_attributes=True
                        )
                        return RepositoryValidation(
                            repository=repository_model, message=message
                        )
                    else:
                        message = f"{repo.name} pepository public key is not found."
                        logger.error(message)
        else:
            message = "Repository name not defined."
            logger.error(message)
    except Exception as e:
        message = "Error decoding JWT token"
        logger.error(f"Error decoding JWT token: {e}")

    return RepositoryValidation(message=message)
