import datetime

from pydantic import Field
from typing_extensions import Annotated

from mxd.presentation.rest_api.groups.mxd.v1.model.base import (
    BaseLabeledMxdModel,
    CvTerm,
    CvTermValue,
    Definition,
    DefinitionValue,
    KeyValue,
    MxdBasicCvTermValue,
    MxdObjectId,
)


class MxdDataProvider(MxdBasicCvTermValue):
    type_: Annotated[str, Field(frozen=True, alias="type")] = "data-provider"


class MxdOntologySource(BaseLabeledMxdModel):
    type_: Annotated[str, Field(frozen=True, alias="type")] = "ontology-source"
    name: None | str = None
    description: None | str = None
    uri: None | str = None
    version: None | str = None

    def get_label(self):
        return self.name or ""


class MxdPerson(BaseLabeledMxdModel):
    type_: Annotated[str, Field(frozen=True, alias="type")] = "person"
    first_name: None | str = None
    last_name: None | str = None
    email: None | str = None
    phone: None | str = None
    address: None | str = None
    institute: None | str = None
    department: None | str = None
    laboratory: None | str = None

    def get_label(self):
        return self.email or ""


class MxdProject(BaseLabeledMxdModel):
    type_: Annotated[str, Field(frozen=True, alias="type")] = "project"
    title: None | str = None
    description: None | str = None
    doi: None | str = None

    def get_label(self):
        return self.title or ""


class MxdFactorDefinition(Definition):
    type_: Annotated[str, Field(frozen=True, alias="type")] = "factor-definition-cv"


class MxdCharacteristicDefinition(Definition):
    type_: Annotated[str, Field(frozen=True, alias="type")] = (
        "characteristic-definition-cv"
    )


class MxdParameterDefinition(Definition):
    type_: Annotated[str, Field(frozen=True, alias="type")] = "parameter-definition-cv"


class MxdStudy(BaseLabeledMxdModel):
    type_: Annotated[str, Field(frozen=True, alias="type")] = "study"
    repository_identifier: Annotated[None | str, Field()] = None
    mxd_identifier: Annotated[None | str, Field()] = None
    title: Annotated[None | str, Field()] = None
    description: Annotated[None | str, Field()] = None
    submission_date: None | datetime.datetime = None
    public_release_date: None | datetime.datetime = None
    revision_number: Annotated[None | int, Field()] = None
    revision_datetime: None | datetime.datetime = None
    dataset_license: Annotated[None | CvTerm | CvTermValue, Field()] = None
    keywords: Annotated[None | list[CvTerm], Field()] = None
    uri_list: None | list[KeyValue] = None
    sample_characteristic_definition_refs: Annotated[
        None | list[MxdObjectId], Field()
    ] = None
    study_factor_definition_refs: Annotated[None | list[MxdObjectId], Field()] = None

    protocol_refs: Annotated[None | list[MxdObjectId], Field()] = None
    reported_metabolite_refs: Annotated[None | list[MxdObjectId], Field()] = None

    raw_data_file_refs: Annotated[None | list[MxdObjectId], Field()] = None
    metadata_file_refs: Annotated[None | list[MxdObjectId], Field()] = None
    result_file_refs: Annotated[None | list[MxdObjectId], Field()] = None
    additional_file_refs: Annotated[None | list[MxdObjectId], Field()] = None

    def get_label(self):
        return self.title or ""


class MxdProtocol(BaseLabeledMxdModel):
    description: Annotated[None | str, Field()] = None
    parameter_definition_refs: Annotated[None | list[MxdObjectId], Field()] = None

    def get_label(self):
        return self.type_ or ""


class MxdSampleCollectionProtocol(MxdProtocol):
    type_: Annotated[str, Field(frozen=True, alias="type")] = (
        "sample-collection-protocol"
    )


class MxdSamplePreparationProtocol(MxdProtocol):
    type_: Annotated[str, Field(frozen=True, alias="type")] = (
        "sample-preparation-protocol"
    )


class MxdChromatographyProtocol(MxdProtocol):
    type_: Annotated[str, Field(frozen=True, alias="type")] = "chromatography-protocol"


class MxdTreatmentProtocol(MxdProtocol):
    type_: Annotated[str, Field(frozen=True, alias="type")] = "treatment-protocol"


class MxdMassSpectrometryProtocol(MxdProtocol):
    type_: Annotated[str, Field(frozen=True, alias="type")] = (
        "mass-spectrometry-protocol"
    )


class MxdDataTransformationProtocol(MxdProtocol):
    type_: Annotated[str, Field(frozen=True, alias="type")] = (
        "data-transformation-protocol"
    )


class MxdMetaboliteIdentificationProtocol(MxdProtocol):
    type_: Annotated[str, Field(frozen=True, alias="type")] = (
        "metabolite-identification-protocol"
    )


class MxdPublication(BaseLabeledMxdModel):
    type_: Annotated[str, Field(frozen=True, alias="type")] = "publication"
    title: None | str = None
    doi: None | str = None
    pub_med_id: None | str = None
    authors: None | list[str] = None
    status_ref: None | MxdObjectId = None

    def get_label(self):
        return self.title or ""


class MxdBasicAssay(BaseLabeledMxdModel):
    type_: Annotated[str, Field(frozen=True, alias="type")] = "assay"
    repository_identifier: Annotated[None | str, Field()] = None
    name: Annotated[None | str, Field()] = None
    technique_type_ref: Annotated[None | MxdObjectId, Field()] = None
    analysis_type_ref: Annotated[None | MxdObjectId, Field()] = None
    technology_type_ref: Annotated[None | MxdObjectId, Field()] = None
    metadata_file_ref: Annotated[None | MxdObjectId, Field()] = None
    study_factor_definition_refs: Annotated[None | list[MxdObjectId], Field()] = None
    sample_characteristic_definition_refs: Annotated[
        None | list[MxdObjectId], Field()
    ] = None
    protocol_refs: Annotated[None | list[MxdObjectId], Field()] = None

    def get_label(self):
        return self.name or ""


class MxdAssay(MxdBasicAssay):
    run_refs: Annotated[None | list[MxdObjectId], Field()] = None

    def get_label(self):
        return self.name or ""


class MxdProtocolRun(BaseLabeledMxdModel):
    type_: Annotated[str, Field(frozen=True, alias="type")] = "protocol-run"
    protocol_ref: Annotated[None | MxdObjectId, Field()] = None
    parameter_values: Annotated[None | list[DefinitionValue], Field()] = None


class MxdSample(BaseLabeledMxdModel):
    type_: Annotated[str, Field(frozen=True, alias="type")] = "sample"
    source_id: Annotated[None | str, Field()] = None
    name: Annotated[None | str, Field()] = None
    characteristic_values: Annotated[None | list[DefinitionValue], Field()] = None
    factor_values: Annotated[None | list[DefinitionValue], Field()] = None

    def get_label(self):
        return self.name or ""


class MxdRun(BaseLabeledMxdModel):
    type_: Annotated[str, Field(frozen=True, alias="type")] = "run"
    name: Annotated[None | str, Field()] = None
    sample_ref: Annotated[None | MxdObjectId, Field()] = None
    protocol_run_refs: Annotated[None | list[str], Field()] = None
    raw_data_file_refs: Annotated[None | list[str], Field()] = None
    result_file_refs: Annotated[None | list[str], Field()] = None
    additional_file_refs: Annotated[None | list[str], Field()] = None


class MxdMetabolite(BaseLabeledMxdModel):
    type_: Annotated[str, Field(frozen=True, alias="type")] = "metabolite"
    name: Annotated[None | str, Field()] = None
    # identifier_refs: Annotated[None | list[MxdObjectId], Field()] = None

    def get_label(self):
        return self.name or ""


class MxdBaseFile(BaseLabeledMxdModel):
    name: Annotated[None | str, Field()] = None
    size: Annotated[None | int, Field(description="File size in bytes")] = None
    hash_sha256: Annotated[None | str, Field()] = None
    format_ref: Annotated[None | MxdObjectId, Field()] = None
    content_refs: Annotated[None | list[MxdObjectId], Field()] = None
    compression_format_ref: Annotated[None | list[MxdObjectId], Field()] = None
    extension: Annotated[None | str, Field()] = None

    def get_label(self):
        return self.name or ""


class MxdRawDataFile(MxdBaseFile):
    type_: Annotated[str, Field(frozen=True, alias="type")] = "raw-data-file"
    metadata_file_refs: Annotated[None | list[str], Field()] = None


class MxdMetadataFile(MxdBaseFile):
    type_: Annotated[str, Field(frozen=True, alias="type")] = "metadata-file"


class MxdResultFile(MxdBaseFile):
    type_: Annotated[str, Field(frozen=True, alias="type")] = "result-file"


class MxdAdditionalFile(MxdBaseFile):
    type_: Annotated[str, Field(frozen=True, alias="type")] = "additional-file"
