import asyncio
import datetime
import hashlib
import json
import pathlib
from functools import lru_cache
from logging import getLogger
from typing import Any

import jsonschema
from dependency_injector.wiring import Provide, inject
from mxd.application.decorators.async_task import async_task
from mxd.application.services.interfaces.cache_service import CacheService
from mxd.infrastructure.persistence.db.db_client import DatabaseClient
from mxd.presentation.rest_api.groups.mxd.v1.model.mxd import (
    AnnouncementFile,
    Dataset,
    DatasetRevision,
    DatasetRevisionStatus,
)
from mxd.presentation.rest_api.groups.mxd.v1.routers.models import (
    CreateDatasetRevisionModel,
    DatasetRevisionError,
    TaskResult,
)
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from mxd.presentation.rest_api.groups.mxd.v1.model.announcement import MxdAnnouncement

logger = getLogger(__name__)

DEFAULT_SCHEMA = (
    "https://www.metabolomexchange.org/schemas/v0.1/announcement-v0.1.schema.json"
)


SUPPORTED_ANNOUNCEMENTS = {
    DEFAULT_SCHEMA: "resources/mxd/announcement-v0.1.schema.json"
}


announcement_schema_file_path = SUPPORTED_ANNOUNCEMENTS[DEFAULT_SCHEMA]


@lru_cache(100)
def load_json(file: str):
    with pathlib.Path(file).open("r") as f:
        json_file = json.load(f)
    return json_file


@inject
async def add_submission(
    repository_id: str,
    accession: str,
    announcement_file_json: dict[str, Any],
    announcement_reason: str,
    task_id: str,
    database_client: DatabaseClient = Provide["gateways.database_client"],
    cache_service: CacheService = Provide["services.cache_service"],
):
    file_cache_key = f"new-announcement:{accession}"
    message = None
    try:
        await cache_service.set_value(
            file_cache_key,
            task_id,
            expiration_time_in_seconds=60,
        )
        logger.info("Checking announcement file schema for %s", accession)
        announcement_schema = None
        if "$schema" in announcement_file_json and announcement_file_json["$schema"]:
            uri = announcement_file_json["$schema"]
            if uri in SUPPORTED_ANNOUNCEMENTS:
                announcement_schema = load_json(SUPPORTED_ANNOUNCEMENTS[uri])
            else:
                raise DatasetRevisionError(f"Unsupported schema {uri}")
        if not announcement_schema:
            announcement_schema = load_json(SUPPORTED_ANNOUNCEMENTS[DEFAULT_SCHEMA])

        jsonschema.validate(
            instance=announcement_file_json,
            schema=announcement_schema,
        )
        logger.info("Announcement file schema is validated for %s", accession)

        logger.info("Checked announcement file schema for %s", accession)
        announcement = MxdAnnouncement.model_validate(announcement_file_json)
        repository_revision = announcement.repository_revision
        repository_revision_datetime = announcement.repository_revision_datetime
        if repository_revision_datetime:
            repository_revision_datetime = repository_revision_datetime.replace(
                tzinfo=None
            )
        file_str = json.dumps(announcement_file_json)
        file_sha256 = hashlib.sha256(file_str.encode()).hexdigest()

        now = datetime.datetime.now(datetime.UTC).replace(tzinfo=None)

        logger.info("Adding dataset revision for %s", accession)
        async with database_client.session() as a_session:
            try:
                session: AsyncSession = a_session
                stmt = (
                    select(Dataset)
                    .where(
                        Dataset.accession == accession,
                        Dataset.repository_id == repository_id,
                    )
                    .limit(1)
                    .with_for_update()
                )
                result = await session.execute(stmt)
                db_dataset = result.scalar_one_or_none()

                if db_dataset is None:
                    raise DatasetRevisionError(
                        f"Dataset {accession} not found in the database."
                    )
                stmt = select(DatasetRevision).where(
                    DatasetRevision.dataset_id == db_dataset.id,
                    DatasetRevision.revision == db_dataset.revision,
                )
                result = await session.execute(stmt)
                latest_revision = result.scalar_one_or_none()
                if latest_revision:
                    stmt = select(AnnouncementFile.hash_sha256).where(
                        AnnouncementFile.id == latest_revision.file_id,
                    )
                    result = await session.execute(stmt)
                    latest_file_sha256 = result.scalar()
                    # if latest_file_sha256 and latest_file_sha256 == file_sha256:
                    #     raise DatasetRevisionError(
                    #         f"Dataset {accession} has the same file already submitted."
                    #     )

                announcement_file = AnnouncementFile(
                    dataset=db_dataset,
                    hash_sha256=file_sha256,
                    file=announcement_file_json,
                )
                stmt = select(func.max(DatasetRevision.revision)).where(
                    DatasetRevision.dataset_id == db_dataset.id
                )
                result = await session.execute(stmt)
                max_revision = result.scalar()
                revision = db_dataset.revision + 1
                if max_revision is not None:
                    if max_revision > db_dataset.revision:
                        revision = max_revision + 1

                dataset_revision = DatasetRevision(
                    dataset=db_dataset,
                    file=announcement_file,
                    task_id=task_id,
                    revision=revision,
                    revision_datetime=now,
                    description=announcement_reason,
                    repository_revision=repository_revision,
                    repository_revision_datetime=repository_revision_datetime,
                    status=DatasetRevisionStatus.VALID,
                )
                db_dataset.updated_at = now
                db_dataset.revision = revision
                db_dataset.revision_datetime = now

                session.add(announcement_file)
                session.add(dataset_revision)
                await session.commit()
                # await session.refresh(announcement_file)
                # await session.refresh(dataset_revision)
                logger.info(
                    "Dataset %s has new revision %s at %s",
                    db_dataset.accession,
                    dataset_revision.revision,
                    dataset_revision.revision_datetime,
                )
                model = CreateDatasetRevisionModel.model_validate(
                    dataset_revision, from_attributes=True
                )
                model.accession = accession
                return TaskResult[CreateDatasetRevisionModel](
                    success=True, result=model
                ).model_dump()
            except DatasetRevisionError as ex:
                message = str(ex)
                await session.rollback()
                logger.error(message)
            except Exception as ex:
                message = f"Failed to add submission task for {accession}"
                logger.error(message)
                logger.exception(ex)
                await session.rollback()

    except jsonschema.ValidationError:
        message = f"Failed to validate file content for {accession}"
        logger.error(message)
        # logger.exception(ex)
        # raise ex
    except Exception:
        message = f"Failed to get file content for {accession}"
        logger.error(message)
        # logger.exception(ex)
        # raise ex
    finally:
        await cache_service.delete_key(file_cache_key)
    return TaskResult[CreateDatasetRevisionModel](
        success=False, message=message
    ).model_dump()


@async_task(app_name="mhd", queue="submission")
def add_submission_task(
    *,
    repository_id: str,
    accession: str,
    announcement_file_json: dict[str, Any],
    announcement_reason: str,
    task_id: str,
    **kwargs,
) -> str:
    coroutine = add_submission(
        repository_id=repository_id,
        accession=accession,
        announcement_file_json=announcement_file_json,
        announcement_reason=announcement_reason,
        task_id=task_id,
    )
    return asyncio.run(coroutine)
