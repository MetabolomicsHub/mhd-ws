import datetime
import decimal
import uuid
from typing import Any, Self

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from pydantic.alias_generators import to_pascal
from typing_extensions import Annotated

NAMESPACE_VALUE = uuid.UUID("efb4f8e4-d08b-4979-916e-600c4985e7f2")
UUID_PATTERN = (
    r"^[-a-zA-Z0-9]+--[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$"
)
MxdObjectId = Annotated[str, Field(pattern=UUID_PATTERN)]


class MxdConfigModel(BaseModel):
    """Base model class to convert python attributes to camel case"""

    model_config = ConfigDict(
        populate_by_name=True,
        JSON_schema_serialization_defaults_required=True,
        field_title_generator=lambda field_name, field_info: to_pascal(
            field_name.replace("_", " ").strip()
        ),
    )


class CvTerm(MxdConfigModel):
    source: None | str = None
    accession: None | str = None
    name: None | str = None

    def get_unique_id(self):
        return f"{self.source or ''},{self.accession or ''},{self.name or ''}"

    def __hash__(self):
        return hash(self.get_unique_id())

    def get_label(self):
        return self.name or ""


class UnitCvTerm(CvTerm): ...


class CvTermValue(CvTerm):
    value: (
        None | str | int | bool | datetime.datetime | float | decimal.Decimal | CvTerm
    ) = None
    unit: None | UnitCvTerm = None

    def get_unique_id(self):
        unit_key = self.unit.get_unique_id() if self.unit else ""
        value_key = (
            self.value.get_unique_id()
            if isinstance(self.unit, CvTerm)
            else str(self.value)
            if self.value is not None
            else ""
        )

        return f"{super().get_unique_id()},{value_key or ''},{unit_key or ''}"

    def get_label(self):
        unit_key = self.unit.get_label() if self.unit else ""
        value_key = (
            self.value.get_label()
            if isinstance(self.unit, CvTerm)
            else str(self.value)
            if self.value is not None
            else ""
        )

        return f"{value_key or ''} {unit_key or ''}[{self.source or ''}, {self.accession or ''}, {self.name or ''}]"


class KeyValue(MxdConfigModel):
    key: None | MxdObjectId | str = None
    value: None | MxdObjectId | str | CvTerm | CvTermValue = None


class BaseMxdModel(MxdConfigModel):
    id_: Annotated[None | str, Field(alias="id")] = None
    type_: Annotated[str, Field(alias="type")]
    created_by_ref: None | MxdObjectId = None
    tags: None | list[KeyValue] = None
    external_references: None | list[KeyValue] = None
    uri_list: None | list[KeyValue] = None

    @field_validator("id_", mode="before")
    @classmethod
    def id_validator(cls, v) -> str:
        if isinstance(v, str):
            try:
                uuid.UUID(v.split("--")[1])
                return v
            except Exception:
                raise ValueError(f"invalid string structure {v}")
        raise ValueError("invalid type")

    @model_validator(mode="wrap")
    @classmethod
    def validate_model(cls, v: Any, handler) -> Self:
        item: BaseLabeledMxdModel = handler(v)

        if item.type_ and not item.id_:
            item.id_ = f"{item.type_}--{uuid.uuid4()}"
        return item

    def get_unique_id(self):
        return self.id_

    def __hash__(self):
        return hash(self.get_unique_id())


class BaseLabeledMxdModel(BaseMxdModel):
    label: Annotated[None | str, Field()] = None

    @model_validator(mode="wrap")
    @classmethod
    def validate_model(cls, v: Any, handler) -> Self:
        item: BaseLabeledMxdModel = handler(v)

        if item.type_ and not item.id_:
            item.id_ = f"{item.type_}--{uuid.uuid4()}"
        if not item.label:
            item.label = item.get_label()
        return item

    def get_label(self):
        return self.id_ or ""


class Definition(BaseLabeledMxdModel):
    name: Annotated[None | str, Field()] = None
    definition_type: Annotated[None | CvTerm, Field()] = None

    @model_validator(mode="wrap")
    @classmethod
    def validate_model(cls, v: Any, handler) -> Self:
        item: MxdBasicCvTermValue = handler(v)
        if item.type_ and not item.id_:
            str_repr = item.get_unique_id()
            identifier_name = f"{item.type_}--{str_repr}"
            identifier = str(uuid.uuid5(NAMESPACE_VALUE, name=identifier_name))
            item.id_ = f"{item.type_}--{identifier}"
        if not item.label:
            item.label = item.get_label()
        return item

    def get_unique_id(self):
        return f"{self.name or ''},{self.definition_type.get_unique_id() if self.definition_type else ''}"

    def __hash__(self):
        return hash(self.get_unique_id())

    def get_label(self):
        return self.name or ""


class DefinitionValue(KeyValue): ...


class MxdBasicCvTermValue(CvTermValue, BaseLabeledMxdModel):
    type_: Annotated[str, Field(frozen=False, alias="type")] = "cv-term-value"

    @model_validator(mode="wrap")
    @classmethod
    def validate_model(cls, v: Any, handler) -> Self:
        item: MxdBasicCvTermValue = handler(v)
        if item.type_ and not item.id_:
            str_repr = item.get_unique_id()
            identifier_name = f"{item.type_}--{str_repr}"
            identifier = str(uuid.uuid5(NAMESPACE_VALUE, name=identifier_name))
            item.id_ = f"{item.type_}--{identifier}"
        if not item.label:
            item.label = item.get_label()
        return item

    def get_label(self):
        return self.value or self.name or self.id_ or ""

    def __hash__(self):
        return hash(self.get_unique_id())


class MxdBasicCvModel(CvTerm, BaseLabeledMxdModel):
    id_: Annotated[None | str, Field(alias="id")] = None
    label: Annotated[None | str, Field()] = None
    type_: Annotated[str, Field(alias="type")]

    @field_validator("id_", mode="before")
    @classmethod
    def id_validator(cls, v) -> str:
        if isinstance(v, str):
            try:
                uuid.UUID(v.split("--")[1])
                return v
            except Exception:
                raise ValueError(f"invalid string structure {v}")
        raise ValueError("invalid type")

    @model_validator(mode="wrap")
    @classmethod
    def validate_model(cls, v: Any, handler) -> Self:
        item: MxdBasicCvModel = handler(v)
        if item.type_ and not item.id_:
            str_repr = item.get_unique_id()
            identifier_name = f"{item.type_}--{str_repr}"
            identifier = str(uuid.uuid5(NAMESPACE_VALUE, name=identifier_name))
            item.id_ = f"{item.type_}--{identifier}"
        if not item.label:
            item.label = item.get_label()
        return item

    def get_label(self):
        return self.name or self.id_ or ""

    def __hash__(self):
        return hash(self.get_unique_id())


class BaseMxdRelationship(BaseMxdModel):
    source_ref: MxdObjectId
    relationship_name: str
    target_ref: MxdObjectId
    source_role: None | str = None
    target_role: None | str = None

    def get_label(self):
        return self.relationship_name
