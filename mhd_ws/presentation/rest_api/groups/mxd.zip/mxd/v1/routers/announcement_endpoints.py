import datetime
import enum
import json
import uuid
from logging import getLogger
from typing import Annotated

from dependency_injector.wiring import Provide, inject
from fastapi import APIRouter, Depends, File, Header, Path, Response, UploadFile, status
from fastapi.responses import FileResponse
from metabolights_utils.common import CamelCaseModel
from mxd.application.services.interfaces.async_task.async_task_service import (
    AsyncTaskService,
    IdGenerator,
)
from mxd.application.services.interfaces.cache_service import CacheService
from mxd.presentation.rest_api.groups.mxd.v1.model.mxd import Dataset
from mxd.presentation.rest_api.groups.mxd.v1.routers.db import get_db
from mxd.presentation.rest_api.groups.mxd.v1.routers.dependencies import (
    RepositoryModel,
    validate_api_token,
)
from mxd.presentation.rest_api.groups.mxd.v1.routers.models import (
    CreateDatasetRevisionModel,
    TaskResult,
)
from mxd.presentation.rest_api.groups.mxd.v1.routers.tasks import add_submission_task
from pydantic import Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

logger = getLogger(__name__)

router = APIRouter(prefix="/v1/pre-alpha")


class TaskStatus(enum.StrEnum):
    INITIATED = "INITIATED"
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"


class MxdAsyncTaskResponse(CamelCaseModel):
    accession: Annotated[
        None | str,
        Field(
            title="MXD Identifier", description="Assigned MetabolomeXchange identifier"
        ),
    ] = None
    task_id: Annotated[
        None | str,
        Field(
            title="Submission Task Id",
            description="MetabolomeXchange submission task id",
        ),
    ] = None
    task_status: Annotated[
        None | TaskStatus, Field(title="Task Status", description="Task status")
    ] = None
    messages: Annotated[
        list[str] | None, Field(title="Messages", description="Announcement messages")
    ] = None
    created_at: Annotated[
        None | datetime.datetime,
        Field(title="Created At", description="Created datetime"),
    ] = None
    updated_at: Annotated[
        datetime.datetime | None,
        Field(title="Updated At", description="Updated datetime"),
    ] = None
    errors: Annotated[
        None | list[str],
        Field(title="Errors", description="MetabolomeXchange submission task errors"),
    ] = None
    result: Annotated[
        None | CreateDatasetRevisionModel,
        Field(title="Task result", description="Task result"),
    ] = None


class Revision(CamelCaseModel):
    mxd_identifier: Annotated[
        str,
        Field(
            title="MXD Identifier", description="Assigned MetabolomeXchange identifier"
        ),
    ]
    repostiory: Annotated[
        str, Field(title="Repository Name", description="Repository name")
    ]
    revision_number: Annotated[
        int, Field(title="Revision number", description="Revision number")
    ]
    announcement_datetime: Annotated[
        datetime.datetime,
        Field(
            title="Announcement Datetime", description="Revision announcement datetime"
        ),
    ]
    revision_comment: Annotated[
        int, Field(title="Revision Comment", description="Revision comment")
    ]


class MxdDatasetRevision(CamelCaseModel):
    revision_number: Annotated[
        int, Field(title="Revision number", description="Revision number")
    ]
    revision_comment: Annotated[
        None | int, Field(title="Revision Comment", description="Revision comment")
    ] = None
    announcement_datetime: Annotated[
        datetime.datetime,
        Field(
            title="Announcement Datetime", description="Revision announcement datetime"
        ),
    ]


class MxdDatasetRevisions(CamelCaseModel):
    mxd_identifier: Annotated[
        str,
        Field(
            title="MXD Identifier", description="Assigned MetabolomeXchange identifier"
        ),
    ]
    repostiory: Annotated[
        str, Field(title="Repository Name", description="Repository name")
    ]
    revisions: Annotated[
        None | list[MxdDatasetRevision],
        Field(title="Dataset revisions", description="Dataset revisions"),
    ] = None


@router.post(
    "/datasets/{accession}/revisions",
    summary="Announce New Dataset Revision",
    description="""
Announce new dataset revision. First public revision is 1. 
If there is any (meta)data update on repository, repository should announce new dataset revision.
After first successful announcement, dataset access level will be public.
""",
    tags=["Dataset Announcements"],
    response_model=MxdAsyncTaskResponse,
    responses={
        200: {
            "description": "MXD Async Task",
            "content": {
                "application/json": {
                    "example": MxdAsyncTaskResponse(
                        mxd_identifier="MXD000001",
                        task_id="create-revision-23a08167-89e8-4e28-a824-38c66f92f437",
                        task_status=TaskStatus.INITIATED,
                        messages=["Task is initiated"],
                        created_at=datetime.datetime(2020, 1, 30),
                        updated_at=None,
                    ).model_dump(by_alias=True)
                }
            },
        },
        400: {
            "description": "Bad Request.",
        },
        401: {
            "description": "Unauthorized.",
        },
        403: {
            "description": "Forbidden request.",
        },
        404: {
            "description": "Not Found.",
        },
    },
)
@inject
async def make_new_announcement(
    response: Response,
    accession: Annotated[
        str,
        Path(
            title="MXD Identifier",
            description="MXD Identifier.",
        ),
    ],
    announcement_reason: Annotated[
        None | str,
        Field(
            title="Announcement reason. ",
            description="Announcement reason. Example: 'Initial revision', 'Update publication DOI', 'Update sample metadata', etc",
        ),
    ],
    file: Annotated[
        UploadFile,
        File(
            title="MetabolomeXchange Dataset Announcement File",
            description="MetabolomeXchange Dataset Announcement File.",
        ),
    ],
    cache_service: CacheService = Depends(Provide["services.cache_service"]),  # noqa: FAST002
    session: Annotated[AsyncSession, Depends(get_db)] = None,
    async_task_service: AsyncTaskService = Depends(  # noqa: FAST002
        Provide["services.async_task_service"]
    ),
    repository: Annotated[None | RepositoryModel, Depends(validate_api_token)] = None,
):
    if not repository:
        response.status_code = status.HTTP_403_FORBIDDEN
        error = "API token is not valid"
        return MxdAsyncTaskResponse(
            errors=[error],
        )

    contents = await file.read()
    # hash_value = hashlib.sha256(contents).hexdigest()
    async with session:
        stmt = select(Dataset.repository_id).where(Dataset.accession == accession)
        result = await session.execute(stmt)
        repository_id = result.scalar()
    if repository_id is None:
        response.status_code = status.HTTP_404_NOT_FOUND
        error = "There is no dataset."
        return MxdAsyncTaskResponse(
            accession=accession,
            errors=[error],
        )
    elif repository_id != repository.id:
        response.status_code = status.HTTP_403_FORBIDDEN
        error = "Repository has no permission to update dataset."
        return MxdAsyncTaskResponse(
            accession=accession,
            errors=[error],
        )

    file_cache_key = f"new-announcement:{accession}"
    task_id = await cache_service.get_value(file_cache_key)
    if task_id is not None:
        error = f"Task id {task_id} already exists for {accession}."
        logger.error(error)
        response.status_code = status.HTTP_425_TOO_EARLY
        return MxdAsyncTaskResponse(
            task_id=task_id,
            errors=[error],
        )
    task_id = str(uuid.uuid4())

    announcement_file_json = json.loads(contents.decode())
    executor = await async_task_service.get_async_task(
        add_submission_task,
        repository_id=repository.id,
        accession=accession,
        announcement_file_json=announcement_file_json,
        announcement_reason=announcement_reason,
        task_id=task_id,
        id_generator=IdGenerator(lambda: task_id),
    )

    result = await executor.start()
    task_id = result.get_id()
    logger.info("New revision task started for %s with task id %s", accession, task_id)

    try:
        updated_task_result = await async_task_service.get_async_task_result(task_id)
    except Exception:
        message = f"Current new revision task failed to start: {task_id}"
        logger.error(message)
        # await cache_service.delete_key(key)
        # raise AsyncTaskStartFailure(resource_id, task_id, message) from ex
        MxdAsyncTaskResponse(
            mxd_identifier=accession,
            task_id=task_id,
            task_status="FAILED",
            messages=["Task failed."],
            created_at=datetime.datetime.now(datetime.UTC),
            updated_at=None,
        )

    if updated_task_result.get_status().upper().startswith("FAIL"):
        logger.error(
            "Current task id:'%s' and its status: %s.",
            updated_task_result.get_id(),
            updated_task_result.get_status(),
        )
    else:
        logger.debug(
            "Current task id:'%s' and its status: %s.",
            updated_task_result.get_id(),
            updated_task_result.get_status(),
        )
    return MxdAsyncTaskResponse(
        mxd_identifier=accession,
        task_id=updated_task_result.get_id(),
        task_status=updated_task_result.get_status(),
        messages=["Task is submitted"],
        created_at=datetime.datetime.now(datetime.UTC),
        updated_at=None,
    )


@router.get(
    "/datasets/{accession}/revisions",
    summary="Get List of Dataset Revisions",
    description="Get list of dataset revisions.",
    tags=["Dataset Announcements"],
    response_model=MxdDatasetRevisions,
    responses={
        200: {
            "description": "Revision List",
        },
        400: {
            "description": "Bad Request.",
        },
        401: {
            "description": "Unauthorized.",
        },
        403: {
            "description": "Forbidden request.",
        },
        404: {
            "description": "Not Found.",
        },
    },
)
@inject
async def get_revisions(
    accession: Annotated[
        str,
        Path(
            title="MXD Identifier.",
            description="MXD Identifier.",
        ),
    ],
    api_token: Annotated[
        str,
        Header(
            title="API token created for the MetabolomExchange partner applications.",
            description="Repository identifier will be used match MXD identifier.",
        ),
    ] = None,
    cache_service: CacheService = Depends(Provide["services.cache_service"]),  # noqa: FAST002
):
    return MxdDatasetRevisions(
        mxd_identifier="MXD000001",
        repostiory="Metabolomics Workbench",
        revisions=[
            MxdDatasetRevision(
                revision_number=1,
                revision_comment="Initial revision",
                announcement_datetime=datetime.datetime(2020, 1, 30),
            ),
            MxdDatasetRevision(
                revision_number=2,
                revision_comment="Publication DOI update",
                announcement_datetime=datetime.datetime(2020, 2, 30),
            ),
        ],
    )


@router.get(
    "/datasets/{mxd_identifier}/revisions/latest",
    summary="Download the Latest Dataset Revision",
    description="""
Download the latest dataset announcement file of the requested dataset. 
Endpoint will return HTTP 401 if dataset is private and api token is not validated.""",
    tags=["Dataset Announcements"],
    response_class=FileResponse,
    responses={
        200: {
            "description": "MXD Announcement File",
        },
        403: {
            "description": "Forbidden request.",
        },
        404: {
            "description": "Not Found.",
        },
    },
)
@inject
async def get_latest_revision(
    mxd_identifier: Annotated[
        str,
        Path(
            title="MXD Identifier.",
            description="MXD Identifier.",
        ),
    ],
    api_token: Annotated[
        str,
        Header(
            title="API token.",
            description="API token",
        ),
    ] = None,
    cache_service: CacheService = Depends(Provide["services.cache_service"]),  # noqa: FAST002
):
    return FileResponse()


@router.get(
    "/datasets/{mxd_identifier}/revisions/{revision_number}",
    summary="Download Dataset Revision",
    description="Download a revision of the selected dataset.",
    tags=["Dataset Announcements"],
    responses={
        200: {
            "description": "MXD Announcement File",
        },
        400: {
            "description": "Bad Request.",
        },
        401: {
            "description": "Unauthorized.",
        },
        403: {
            "description": "Forbidden request.",
        },
        404: {
            "description": "Not Found.",
        },
    },
)
@inject
async def get_revision(
    api_token: Annotated[
        str,
        Header(
            title="API token created for the MetabolomExchange partner applications.",
            description="Repository identifier will be used match MXD identifier.",
        ),
    ],
    mxd_identifier: Annotated[
        str,
        Path(
            title="MXD Identifier.",
            description="MXD Identifier.",
        ),
    ],
    revision_number: Annotated[
        None,
        Path(
            title="Announcement task id.",
            description="Announcement task id.",
        ),
    ],
    cache_service: CacheService = Depends(Provide["services.cache_service"]),  # noqa: FAST002
):
    return FileResponse()


@router.get(
    "/datasets/{accession}/tasks/{task_id}",
    summary="Check Result of Any Dataset Revision Async Task",
    description="Check result of any dataset revision task (new announcement, delete dataset, delete revision, etc.).",
    tags=["Dataset Announcements"],
    response_model=MxdAsyncTaskResponse,
    responses={
        200: {
            "description": "MXD Async Task",
            "content": {
                "application/json": {
                    "example": MxdAsyncTaskResponse(
                        mxd_identifier="MXD000001",
                        task_id="create-revision-23a08167-89e8-4e28-a824-38c66f92f437",
                        task_status=TaskStatus.SUCCESS,
                        messages=["Task is completed"],
                        created_at=datetime.datetime(2020, 1, 30),
                        updated_at=datetime.datetime(2020, 3, 30),
                    ).model_dump(by_alias=True)
                }
            },
        },
        400: {
            "description": "Bad Request.",
        },
        401: {
            "description": "Unauthorized.",
        },
        403: {
            "description": "Forbidden request.",
        },
        404: {
            "description": "Not Found.",
        },
    },
)
@inject
async def get_task_status(
    response: Response,
    accession: Annotated[
        str,
        Path(
            title="MXD Identifier",
            description="MXD Identifier.",
        ),
    ],
    task_id: Annotated[
        None | str,
        Field(
            title="Task id. ",
            description="task id.",
        ),
    ],
    cache_service: CacheService = Depends(Provide["services.cache_service"]),  # noqa: FAST002
    session: Annotated[AsyncSession, Depends(get_db)] = None,
    async_task_service: AsyncTaskService = Depends(  # noqa: FAST002
        Provide["services.async_task_service"]
    ),
    repository: Annotated[None | RepositoryModel, Depends(validate_api_token)] = None,
):
    if not repository:
        response.status_code = status.HTTP_400_BAD_REQUEST
        return MxdAsyncTaskResponse(errors=["Invalid API token"])
    task_result = None
    try:
        task_result = await async_task_service.get_async_task_result(task_id)
        if not task_result.is_ready():
            file_cache_key = f"new-announcement:{accession}"
            cached_task_id = await cache_service.get_value(file_cache_key)
            if cached_task_id:
                return MxdAsyncTaskResponse(
                    accession=accession,
                    task_id=task_result.get_id(),
                    task_status=TaskStatus(task_result.get_status()),
                    messages=["Task is not completed yet."],
                )
            response.status_code = status.HTTP_404_NOT_FOUND
            return MxdAsyncTaskResponse(
                accession=accession, errors=[f"There is no task {task_id}."]
            )
        try:
            # if task_result.is_successful():
            result = task_result.get()
            output = TaskResult[CreateDatasetRevisionModel].model_validate(result)
            if output.success:
                return MxdAsyncTaskResponse(
                    accession=accession,
                    task_id=task_result.get_id(),
                    task_status=TaskStatus(task_result.get_status()),
                    result=output.result,
                )
            return MxdAsyncTaskResponse(
                accession=accession,
                task_id=task_result.get_id(),
                task_status=TaskStatus.FAILED,
                errors=[output.message],
            )
        except Exception as ex:
            response.status_code = status.HTTP_400_BAD_REQUEST

            return MxdAsyncTaskResponse(
                accession=accession,
                task_id=task_result.get_id(),
                task_status=TaskStatus.FAILED,
                errors=[str(ex)],
            )
        finally:
            if task_result:
                task_result.revoke()

    except Exception as ex:
        message = f"Current validation task failed to start: {task_id}"
        logger.error(message)
        return MxdAsyncTaskResponse(
            accession=accession, task_status=TaskStatus.FAILED, errors=[str(ex)]
        )


@router.delete(
    "/datasets/{mxd_identifier}/revisions",
    summary="Delete All Dataset Revisions",
    description="""
Delete dataset and make it private
""",
    tags=["Dataset Announcements [Maintenance]"],
    response_model=MxdAsyncTaskResponse,
    responses={
        200: {
            "description": "MXD Async Task",
            "content": {
                "application/json": {
                    "example": MxdAsyncTaskResponse(
                        mxd_identifier="MXD000001",
                        task_id="delete-revisions-d3a08167-89e8-4e28-a824-38c66f92f437",
                        task_status=TaskStatus.INITIATED,
                        messages=["Task is initiated"],
                        created_at=datetime.datetime(2020, 1, 30),
                        updated_at=None,
                    ).model_dump(by_alias=True)
                }
            },
        },
        400: {
            "description": "Bad Request.",
        },
        401: {
            "description": "Unauthorized.",
        },
        403: {
            "description": "Forbidden request.",
        },
        404: {
            "description": "Not Found.",
        },
    },
)
@inject
async def delete_dataset(
    api_token: Annotated[
        str,
        Header(
            title="API token.",
            description="API token",
        ),
    ],
    mxd_identifier: Annotated[
        str,
        Path(
            title="MXD Identifier.",
            description="MXD Identifier.",
        ),
    ],
    cache_service: CacheService = Depends(Provide["services.cache_service"]),  # noqa: FAST002
):
    return MxdAsyncTaskResponse(
        mxd_identifier="MXD000001",
        task_id="delete-revisions-d3a08167-89e8-4e28-a824-38c66f92f437",
        task_status=TaskStatus.COMPLETED,
        messages=["Task is completed"],
        created_at=datetime.datetime(2020, 1, 30),
        updated_at=None,
    )


@router.put(
    "/datasets/{mxd_identifier}/revisions/{revision_number}",
    summary="Update Dataset Revision",
    description="""
Update dataset revision. Only latest dataset revision can be updated.
""",
    tags=["Dataset Announcements [Maintenance]"],
    response_model=MxdAsyncTaskResponse,
    responses={
        200: {
            "description": "MXD Async Task",
            "content": {
                "application/json": {
                    "example": MxdAsyncTaskResponse(
                        mxd_identifier="MXD000001",
                        task_id="update-revision-a3a08167-89e8-4e28-a824-38c66f92f437",
                        task_status=TaskStatus.INITIATED,
                        messages=["Task is initiated"],
                        created_at=datetime.datetime(2020, 1, 30),
                        updated_at=None,
                    ).model_dump(by_alias=True)
                }
            },
        },
        400: {
            "description": "Bad Request.",
        },
        401: {
            "description": "Unauthorized.",
        },
        403: {
            "description": "Forbidden request.",
        },
        404: {
            "description": "Not Found.",
        },
    },
)
@inject
async def Update_dataset_revision(
    api_token: Annotated[
        str,
        Header(
            title="API token.",
            description="API token",
        ),
    ],
    mxd_identifier: Annotated[
        str,
        Path(
            title="MXD Identifier.",
            description="MXD Identifier.",
        ),
    ],
    revision_number: Annotated[
        int,
        Path(
            title="Revision number",
            description="Revision number",
        ),
    ],
    file: Annotated[
        UploadFile,
        File(
            title="MetabolomeXchange Dataset Announcement File",
            description="MetabolomeXchange Dataset Announcement File.",
        ),
    ],
    cache_service: CacheService = Depends(Provide["services.cache_service"]),  # noqa: FAST002
):
    return MxdAsyncTaskResponse(
        mxd_identifier="MXD000001",
        task_id="delete-revisions-d3a08167-89e8-4e28-a824-38c66f92f437",
        task_status=TaskStatus.COMPLETED,
        messages=["Task is completed"],
        created_at=datetime.datetime(2020, 1, 30),
        updated_at=None,
    )


@router.delete(
    "/datasets/{mxd_identifier}/revisions/{revision_number}",
    summary="Delete Dataset Revision",
    description="""
Delete dataset revision. Only the latest revision can be deleted.
""",
    tags=["Dataset Announcements [Maintenance]"],
    response_model=MxdAsyncTaskResponse,
    responses={
        200: {
            "description": "MXD Async Task",
            "content": {
                "application/json": {
                    "example": MxdAsyncTaskResponse(
                        mxd_identifier="MXD000001",
                        task_id="delete-revision-13a08167-89e8-4e28-a824-38c66f92f437",
                        task_status=TaskStatus.INITIATED,
                        messages=["Task is initiated"],
                        created_at=datetime.datetime(2020, 1, 30),
                        updated_at=None,
                    ).model_dump(by_alias=True)
                }
            },
        },
        400: {
            "description": "Bad Request.",
        },
        401: {
            "description": "Unauthorized.",
        },
        403: {
            "description": "Forbidden request.",
        },
        404: {
            "description": "Not Found.",
        },
    },
)
@inject
async def delete_dataset_revision(
    api_token: Annotated[
        str,
        Header(
            title="API token.",
            description="API token",
        ),
    ],
    mxd_identifier: Annotated[
        str,
        Path(
            title="MXD Identifier.",
            description="MXD Identifier.",
        ),
    ],
    revision_number: Annotated[
        int,
        Path(
            title="Revision number",
            description="Revision number",
        ),
    ],
    cache_service: CacheService = Depends(Provide["services.cache_service"]),  # noqa: FAST002
):
    now = datetime.datetime.now(datetime.UTC)
    return MxdAsyncTaskResponse(
        mxd_identifier="MXD000001",
        task_id="delete-revisions-d3a08167-89e8-4e28-a824-38c66f92f437",
        task_status=TaskStatus.INITIATED,
        messages=["Task is initiated."],
        created_at=datetime.datetime(2020, 1, 30),
        updated_at=None,
    )


@router.post(
    "/validations/mxd-datasets",
    summary="Validate MetabolomeXchange Dataset File",
    description="Validate Dataset Announcement File and return validation results.",
    tags=["Dataset Validation"],
    response_model=MxdAsyncTaskResponse,
)
@inject
async def make_new_announcement_validation(
    api_token: Annotated[
        str,
        Header(
            title="API token.",
            description="API token.",
        ),
    ],
    file: Annotated[
        UploadFile,
        File(
            title="Validate MetabolomeXchange Dataset File",
            description="Validate MetabolomeXchange Dataset File.",
        ),
    ],
    cache_service: CacheService = Depends(Provide["services.cache_service"]),  # noqa: FAST002
):
    now = datetime.datetime.now(datetime.UTC)
    return MxdAsyncTaskResponse(
        mxd_identifier="MXD000001",
        task_id="validate-mxd-dataset-d3a08167-89e8-4e28-a824-38c66f92f437",
        task_status=TaskStatus.INITIATED,
        messages=["Task is initiated"],
        created_at=datetime.datetime(2020, 1, 30),
        updated_at=None,
    )


@router.post(
    "/validations/announcement-files",
    summary="Validate Dataset Announcement File",
    description="Validate Dataset Announcement File and return validation results.",
    tags=["Dataset Validation"],
    response_model=MxdAsyncTaskResponse,
)
@inject
async def make_new_announcement_validation(
    api_token: Annotated[
        str,
        Header(
            title="API token.",
            description="API token.",
        ),
    ],
    file: Annotated[
        UploadFile,
        File(
            title="MetabolomeXchange Dataset Announcement File",
            description="MetabolomeXchange Dataset Announcement File.",
        ),
    ],
    cache_service: CacheService = Depends(Provide["services.cache_service"]),  # noqa: FAST002
):
    now = datetime.datetime.now(datetime.UTC)
    return MxdAsyncTaskResponse(
        mxd_identifier="MXD000001",
        task_id="validate-announcement-file-d3a08167-89e8-4e28-a824-38c66f92f437",
        task_status=TaskStatus.INITIATED,
        messages=["Task is initiated"],
        created_at=datetime.datetime(2020, 1, 30),
        updated_at=None,
    )


@router.get(
    "/validations/{task_id}",
    summary="Check and Get Result of Validation Task",
    description="Check and get result of validation task. Validation results will be stored for up to 60 minutes.",
    tags=["Dataset Validation"],
    response_model=MxdAsyncTaskResponse,
)
@inject
async def get_announcement_validation_task(
    api_token: Annotated[
        str,
        Field(
            title="API token created for the MetabolomExchange partner applications.",
            description="Repository identifier will be used match MXD identifier.",
        ),
    ],
    task_id: Annotated[
        str,
        Field(
            title="Announcement task id.",
            description="Announcement task id.",
        ),
    ],
    cache_service: CacheService = Depends(Provide["services.cache_service"]),  # noqa: FAST002
):
    return MxdAsyncTaskResponse(
        mxd_identifier="MXD000001",
        task_id="validate-announcement-file-d3a08167-89e8-4e28-a824-38c66f92f437",
        task_status=TaskStatus.COMPLETED,
        messages=["Task is completed"],
        created_at=datetime.datetime(2020, 1, 30),
        updated_at=None,
    )
