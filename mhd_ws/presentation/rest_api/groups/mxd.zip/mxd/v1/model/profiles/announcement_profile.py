import datetime
import decimal
from typing import Literal

from pydantic import Field, ValidationError, field_validator
from typing_extensions import Annotated

from mxd.presentation.rest_api.groups.mxd.v1.model.announcement import Profile
from mxd.presentation.rest_api.groups.mxd.v1.model.base import (
    MxdConfigModel,
)


class CvDefinition(MxdConfigModel):
    label: str
    name: str
    uri: str
    prefix: str
    alternative_labels: None | list[str] = None
    alternative_prefixes: None | list[str] = None


class CvTermDefinition(MxdConfigModel):
    accession: str
    name: str
    source: str

    def __hash__(self):
        return hash(f"[{self.source}, {self.accession}, {self.name}]")


class CvTermValueDefinition(CvTermDefinition):
    value: (
        str
        | int
        | bool
        | datetime.datetime
        | float
        | decimal.Decimal
        | CvTermDefinition
    )
    unit: None | CvDefinition = None


class CvTermPlaceholder(MxdConfigModel):
    source: str
    accession: str


class ProfileValidation(MxdConfigModel):
    name: str
    negate: bool = False


class ProfileCvTermValidation(ProfileValidation):
    allowed_missing_cv_terms: None | list[CvTermDefinition] = None
    allowed_placeholder_values: None | list[CvTermPlaceholder] = None


class AllowedCvList(ProfileCvTermValidation):
    name: str = "allowed-cv-list"
    source_names: list[str]
    allow_other_sources: bool = False


class ParentCvTerm(MxdConfigModel):
    cv_term: CvTermDefinition
    allow_only_leaf: bool = False
    allow_parent: None | bool = False
    excluded_cv_terms: None | list[CvTermDefinition] = None
    index_cv_terms: None | bool = True


class AllowedChildrenCvTerms(ProfileCvTermValidation):
    name: str = "allowed-children-cv-terms"
    parent_cv_terms: list[ParentCvTerm]


class AllowedCvTerms(ProfileCvTermValidation):
    name: str = "allowed-cv-terms"
    cv_terms: None | list[CvTermDefinition]


class AccessibleURI(ProfileCvTermValidation):
    name: str = "accessible-uri"
    max_retries: int = 1
    retry_period_in_seconds: int = 0


class AccessibleCompactURI(ProfileCvTermValidation):
    name: str = "accessible-compact-uri"
    default_prefix: None | str = None
    allow_null_value: bool = False
    follow_redirects: bool = False


class AllowAnyCvTerm(ProfileCvTermValidation):
    name: str = "allow-any-cv-term"


class RegexValidation(ProfileValidation):
    name: str = "regex-validation"
    pattern: str
    allow_null_value: bool = False


class ProfileValidationList(ProfileValidation):
    name: str = "validation-list"
    controls: list[ProfileValidation] = []
    join_operator: Literal["and", "or"] = "and"

    @field_validator("controls", mode="before")
    @classmethod
    def controls_validator(cls, value):
        if not value:
            return []
        return_value = []
        if isinstance(value, list):
            for item in value:
                if isinstance(item, ProfileValidation):
                    return_value.append(item)
                elif isinstance(item, dict) and "name" in item:
                    validation_name = item["name"]
                    validator = VALIDATORS.get(validation_name)
                    if validator:
                        return_value.append(validator.model_validate(item))
                    else:
                        raise ValidationError(
                            f"invalid validator name {validation_name}"
                        )

        else:
            raise ValidationError(f"invalid value {value}")
        return return_value


# ProfileValidationList.model_rebuild()
VALIDATORS: dict[str, type[ProfileValidation]] = {
    "validation-list": ProfileValidationList,
    "regex-validation": RegexValidation,
    "allowed-cv-terms": AllowedCvTerms,
    "allowed-children-cv-terms": AllowedChildrenCvTerms,
    "allow-any-cv-term": AllowAnyCvTerm,
    "allowed-cv-list": AllowedCvList,
    "accessible-uri": AccessibleURI,
    "accessible-compact-uri": AccessibleCompactURI,
}


class AnnouncedDataFileProfile(MxdConfigModel):
    name: Annotated[str, Field(min_length=2)]
    format: Annotated[
        CvTermDefinition,
        Field(
            json_schema_extra={
                "profile_validation": AllowedChildrenCvTerms(
                    parent_cv_terms=[
                        ParentCvTerm(
                            cv_term=CvTermDefinition(
                                source="MS",
                                accession="MS:1000560",
                                name="mass spectrometer file format",
                            ),
                        )
                    ]
                ).model_dump(serialize_as_any=True)
            }
        ),
    ]
    content: Annotated[
        list[CvTermDefinition],
        Field(
            json_schema_extra={
                "profile_validation": AllowedChildrenCvTerms(
                    parent_cv_terms=[
                        ParentCvTerm(
                            cv_term=CvTermDefinition(
                                source="MS",
                                accession="MS:1000524",
                                name="data file content",
                            ),
                        ),
                        ParentCvTerm(
                            cv_term=CvTermDefinition(
                                source="NCIT",
                                accession="NCIT:C25474",
                                name="Data",
                            ),
                            allow_only_leaf=False,
                        ),
                    ]
                ).model_dump(serialize_as_any=True)
            }
        ),
    ]

    file_uri_list: Annotated[
        list[CvTermValueDefinition],
        Field(
            min_length=1,
            json_schema_extra={
                "profile_validation": ProfileValidationList(
                    controls=[
                        AllowedCvTerms(
                            cv_terms=[
                                CvTermDefinition(
                                    source="EDAM", accession="EDAM:1047", name="URI"
                                ),
                                CvTermDefinition(
                                    source="NCIT",
                                    accession="NCIT:C100047",
                                    name="FTP Protocol",
                                ),
                            ]
                        ),
                        AccessibleURI(),
                    ]
                ).model_dump(serialize_as_any=True)
            },
        ),
    ]


class AnnouncementContactProfile(MxdConfigModel):
    first_name: Annotated[str, Field(min_length=2)]
    last_name: Annotated[str, Field(min_length=2)]
    email: Annotated[
        str,
        Field(
            json_schema_extra={
                "profile_validation": RegexValidation(
                    pattern=r"^[^@]+@[^@]+\.[^@]+$"
                ).model_dump(serialize_as_any=True)
            }
        ),
    ]
    institute: None | str = None


class AnnouncementPublicationProfile(MxdConfigModel):
    title: Annotated[str, Field(min_length=5)]
    doi: Annotated[
        None | str,
        Field(
            json_schema_extra={
                "profile_validation": ProfileValidationList(
                    controls=[
                        RegexValidation(
                            pattern=r"^10[.].+/.+$",
                            allow_null_value=True,
                        ),
                        AccessibleCompactURI(
                            default_prefix="doi", allow_null_value=True
                        ),
                    ],
                ).model_dump(serialize_as_any=True)
            }
        ),
    ] = None
    pub_med_id: Annotated[
        None | str,
        Field(
            json_schema_extra={
                "profile_validation": ProfileValidationList(
                    controls=[
                        RegexValidation(
                            pattern=r"^[0-9]{1,20}$", allow_null_value=True
                        ),
                        AccessibleCompactURI(
                            default_prefix="pmid", allow_null_value=True
                        ),
                    ]
                ).model_dump(serialize_as_any=True)
            }
        ),
    ] = None
    authors: Annotated[
        list[str],
        Field(
            min_length=1,
            json_schema_extra={
                "profile_validation": RegexValidation(
                    pattern=r"^.{2,}$", allow_null_value=True
                ).model_dump(serialize_as_any=True)
            },
        ),
    ]
    status: Annotated[
        CvTermDefinition,
        Field(
            json_schema_extra={
                "profile_validation": AllowedChildrenCvTerms(
                    parent_cv_terms=[
                        ParentCvTerm(
                            cv_term=CvTermDefinition(
                                source="EFO",
                                accession="EFO:0001742",
                                name="publication status",
                            ),
                        )
                    ]
                ).model_dump(serialize_as_any=True)
            }
        ),
    ]


class ReportedMetaboliteProfile(MxdConfigModel):
    name: Annotated[str, Field()]


class AnnouncementProfile(Profile):
    schema_name: Annotated[str, Field(alias="$schema")]
    validation_profiles: Annotated[list[str], Field(min_length=1)]
    repository_identifier: Annotated[str, Field(min_length=2)]
    repository_revision: Annotated[None | int, Field()] = None
    repository_revision_datetime: Annotated[None | datetime.datetime, Field()] = None

    mxd_identifier: Annotated[str, Field(pattern=r"MHD[A-Z][0-9]{6,6}")]
    # additional_identifiers: Annotated[None | list[KeyValue], Field()] = None
    dataset_license: Annotated[CvTermDefinition, Field()]
    title: Annotated[str, Field(min_length=5)]
    description: Annotated[str, Field(min_length=5)]
    submission_date: Annotated[datetime.datetime, Field()]
    public_release_date: Annotated[datetime.datetime, Field()]

    mxd_metadata_file_uri: Annotated[
        CvTermValueDefinition,
        Field(
            json_schema_extra={
                "profile_validation": ProfileValidationList(
                    controls=[
                        AllowedCvTerms(
                            cv_terms=[
                                CvTermDefinition(
                                    source="EDAM", accession="EDAM:1047", name="URI"
                                ),
                                CvTermDefinition(
                                    source="NCIT",
                                    accession="NCIT:C100047",
                                    name="FTP Protocol",
                                ),
                            ]
                        ),
                        AccessibleURI(),
                    ]
                ).model_dump(serialize_as_any=True)
            }
        ),
    ]

    submitter_keywords: Annotated[
        list[CvTermDefinition],
        Field(
            json_schema_extra={
                "profile_validation": AllowAnyCvTerm(
                    allowed_placeholder_values=[
                        CvTermPlaceholder(source="MHD", accession="MHD:000001")
                    ],
                ).model_dump(serialize_as_any=True)
            }
        ),
    ]
    publications: Annotated[None | list[AnnouncementPublicationProfile], Field()]
    submitters: Annotated[None | list[AnnouncementContactProfile], Field(min_length=1)]
    principal_investigators: Annotated[
        None | list[AnnouncementContactProfile], Field(min_length=1)
    ]

    disease: Annotated[
        None | list[CvTermDefinition],
        Field(
            json_schema_extra={
                "profile_validation": AllowedCvList(source_names=["DOID"]).model_dump(
                    serialize_as_any=True
                )
            }
        ),
    ] = None
    organism: Annotated[
        list[CvTermDefinition],
        Field(
            min_length=1,
            json_schema_extra={
                "profile_validation": AllowedCvList(
                    source_names=["ENVO", "NCBITAXON"]
                ).model_dump(serialize_as_any=True)
            },
        ),
    ]
    organism_part: Annotated[
        list[CvTermDefinition],
        Field(
            min_length=1,
            json_schema_extra={
                "profile_validation": AllowedCvList(
                    source_names=["BTO", "UBERON"]
                ).model_dump()
            },
        ),
    ]
    instrument: Annotated[
        list[CvTermDefinition],
        Field(
            min_length=1,
            json_schema_extra={
                "profile_validation": AllowedChildrenCvTerms(
                    parent_cv_terms=[
                        ParentCvTerm(
                            cv_term=CvTermDefinition(
                                source="MS",
                                accession="MS:1000031",
                                name="instrument model",
                            ),
                            excluded_cv_terms=[
                                CvTermDefinition(
                                    source="MS",
                                    accession="MS:1000491",
                                    name="Dionex instrument model",
                                ),
                                CvTermDefinition(
                                    source="MS",
                                    accession="MS:1000488",
                                    name="Hitachi instrument model",
                                ),
                            ],
                        )
                    ]
                ).model_dump(serialize_as_any=True)
            },
        ),
    ]

    measurement_methodology: Annotated[
        list[CvTermDefinition],
        Field(
            min_length=1,
            json_schema_extra={
                "profile_validation": AllowedCvTerms(
                    cv_terms=[
                        CvTermDefinition(
                            source="MSIO",
                            accession="MSIO:0000100",
                            name="targeted metabolite profiling",
                        ),
                        CvTermDefinition(
                            source="MSIO",
                            accession="MSIO:0000101",
                            name="untargeted metabolite profiling",
                        ),
                    ]
                ).model_dump(serialize_as_any=True)
            },
        ),
    ]

    technology_type: Annotated[
        list[CvTermDefinition],
        Field(
            min_length=1,
            json_schema_extra={
                "profile_validation": AllowedCvTerms(
                    cv_terms=[
                        CvTermDefinition(
                            source="OBI",
                            accession="OBI:0000470",
                            name="mass spectrometry assay",
                        ),
                        CvTermDefinition(
                            source="OBI",
                            accession="OBI:0000623",
                            name="NMR spectroscopy assay",
                        ),
                    ]
                ).model_dump(serialize_as_any=True)
            },
        ),
    ]  # NMR, MS, ...
    analysis_type: Annotated[
        list[CvTermDefinition],
        Field(
            min_length=1,
            json_schema_extra={
                "profile_validation": AllowedChildrenCvTerms(
                    parent_cv_terms=[
                        ParentCvTerm(
                            cv_term=CvTermDefinition(
                                source="OBI",
                                accession="OBI:0000470",
                                name="mass spectrometry assay",
                            ),
                            allow_only_leaf=False,
                            allow_parent=False,
                        ),
                        ParentCvTerm(
                            cv_term=CvTermDefinition(
                                source="OBI",
                                accession="OBI:0000470",
                                name="NMR spectroscopy assay",
                            ),
                            allow_only_leaf=False,
                            allow_parent=True,
                        ),
                    ]
                ).model_dump(serialize_as_any=True)
            },
        ),
    ]  # LC-MS, GC-MS, ...

    full_dataset_uri_list: Annotated[
        list[CvTermValueDefinition],
        Field(
            min_length=1,
            json_schema_extra={
                "profile_validation": ProfileValidationList(
                    controls=[
                        AllowedCvTerms(
                            cv_terms=[
                                CvTermDefinition(
                                    source="EDAM", accession="EDAM:1047", name="URI"
                                ),
                                CvTermDefinition(
                                    source="NCIT",
                                    accession="NCIT:C100047",
                                    name="FTP Protocol",
                                ),
                            ]
                        ),
                        AccessibleURI(),
                    ]
                ).model_dump(serialize_as_any=True)
            },
        ),
    ]

    # repository_metadata_file_uri_list: Annotated[
    #     None | list[AnnouncedDataFileProfile], Field()
    # ]
    raw_data_file_uri_list: Annotated[
        list[AnnouncedDataFileProfile], Field(min_length=1)
    ]
    # result_file_uri_list: Annotated[None | list[AnnouncedDataFileProfile], Field()]

    reported_metabolites: Annotated[None | list[ReportedMetaboliteProfile], Field()] = (
        None
    )
