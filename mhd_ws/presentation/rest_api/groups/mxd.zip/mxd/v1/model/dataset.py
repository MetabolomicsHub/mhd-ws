from typing import Any, Sequence

from pydantic import Field, field_validator
from pydantic.alias_generators import to_pascal
from typing_extensions import Annotated

from mxd.presentation.rest_api.groups.mxd.v1.model import domain, relationships
from mxd.presentation.rest_api.groups.mxd.v1.model.base import (
    BaseLabeledMxdModel,
    BaseMxdModel,
    BaseMxdRelationship,
    MxdBasicCvModel,
)
from mxd.presentation.rest_api.groups.mxd.v1.model.relationships import (
    MxdRelationship,
)


class MxdBundle(BaseLabeledMxdModel):
    type_: Annotated[str, Field(frozen=True, alias="type")] = "bundle"
    name: Annotated[None | str, Field()] = None
    description: Annotated[None | str, Field()] = None
    start_item_refs: Annotated[list[Any], Field()] = []
    nodes: Annotated[list[BaseLabeledMxdModel], Field()] = []
    relationships: Annotated[list[BaseMxdRelationship], Field()] = []

    @field_validator("nodes", mode="before")
    @classmethod
    def node_validator(cls, v) -> list[BaseMxdModel]:
        if isinstance(v, list):
            items = []
            for item in v:
                if isinstance(item, BaseMxdModel):
                    items.append(item)
                elif isinstance(item, dict):
                    class_name = "Mxd" + to_pascal(item["type"].replace("-", "_"))
                    if hasattr(domain, class_name):
                        class_object = getattr(domain, class_name)
                        items.append(class_object.model_validate(item))
                    elif item["type"].endswith("-cv"):
                        items.append(MxdBasicCvModel.model_validate(item))
                else:
                    raise ValueError("invalid type in nodes")
            return items

        raise ValueError("invalid type")

    @field_validator("relationships", mode="before")
    @classmethod
    def relationship_validator(cls, v) -> list[BaseMxdRelationship]:
        if isinstance(v, list):
            items = []
            for item in v:
                if isinstance(item, BaseMxdRelationship):
                    items.append(item)
                elif isinstance(item, dict):
                    class_name = "Mxd" + to_pascal(item["type"].replace("-", "_"))
                    if hasattr(relationships, class_name):
                        class_object = getattr(relationships, class_name)
                        items.append(class_object.model_validate(item))
                else:
                    raise ValueError("invalid type in nodes")
            return items

        raise ValueError("invalid type")


class MxdDataset(BaseLabeledMxdModel):
    type_: Annotated[str, Field(frozen=True, alias="type")] = "dataset"
    objects: dict[str, BaseLabeledMxdModel] = {}

    def add(self, item: BaseLabeledMxdModel) -> BaseLabeledMxdModel:
        self.objects[item.id_] = item

    def link(
        self,
        source: BaseLabeledMxdModel,
        relationship_name: str,
        target: BaseLabeledMxdModel,
        add_reverse_relationship: bool = False,
        reverse_relationship_name: None | str = None,
    ) -> BaseLabeledMxdModel:
        link = MxdRelationship(
            source_ref=source.id_,
            relationship_name=relationship_name,
            target_ref=target.id_,
        )
        self.objects[link.id_] = link
        if add_reverse_relationship:
            reverse_relationship_name = (
                reverse_relationship_name
                if reverse_relationship_name
                else relationship_name
            )
            link = MxdRelationship(
                source=target.id_,
                relationship_name=reverse_relationship_name,
                target_ref=source.id_,
            )
        self.objects[link.id_] = link

    def add_node(self, item: BaseLabeledMxdModel) -> BaseLabeledMxdModel:
        self.objects[item.id_] = item

    def add_relationship(self, item: BaseMxdRelationship) -> BaseLabeledMxdModel:
        self.objects[item.id_] = item

    def create_bundle(self, start_item_refs: Sequence[str]) -> MxdBundle:
        bundle = MxdBundle()
        iterated_items: set[str] = set()
        for identifier, item in self.objects.items():
            if identifier not in iterated_items:
                iterated_items.add(identifier)
                if identifier in start_item_refs:
                    bundle.start_item_refs.append(identifier)
                if isinstance(item, BaseMxdRelationship):
                    bundle.relationships.append(item)
                else:
                    bundle.nodes.append(item)

        def sort_key(item: BaseLabeledMxdModel):
            if item.id_ in start_item_refs:
                return (0, item.type_, item.label, item.id_)
            if isinstance(item, BaseMxdRelationship):
                return (
                    0,
                    item.source_ref,
                    item.relationship_name,
                    item.target_ref,
                    item.id_,
                )
            if item.type_.endswith("-cv"):
                return (100, item.type_, item.label, item.id_)
            return (2, item.type_, item.label, item.id_)

        bundle.nodes.sort(key=sort_key)
        bundle.relationships.sort(key=sort_key)
        return bundle

    @classmethod
    def from_bundle(cls, bundle: MxdBundle) -> "MxdDataset":
        dataset = cls()
        for item in bundle.all_items:
            dataset.objects[item.id_] = item

        return dataset
