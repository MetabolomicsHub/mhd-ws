import datetime

from pydantic import Field
from typing_extensions import Annotated

from mxd.presentation.rest_api.groups.mxd.v1.model.base import (
    CvTerm,
    CvTermValue,
    KeyValue,
    MxdConfigModel,
)


class MxdAnnouncementContact(MxdConfigModel):
    first_name: None | str
    last_name: None | str
    email: None | str
    institute: None | str = None


class MxdAnnouncementPublication(MxdConfigModel):
    title: None | str
    doi: None | str = None
    pub_med_id: None | str = None
    authors: None | list[str] = None
    status: None | CvTerm


class MxdRevision(MxdConfigModel):
    revision_number: Annotated[None | int, Field()]
    revision_datetime: None | datetime.datetime
    comment: None | str


class MxdReportedMetabolite(MxdConfigModel):
    name: Annotated[None | str, Field()]


class MxdAnnouncedDataFile(MxdConfigModel):
    name: Annotated[None | str, Field()]
    format: Annotated[None | CvTerm, Field()]
    content: Annotated[None | list[CvTerm], Field()]
    file_uri_list: Annotated[None | list[CvTermValue], Field()]


class Profile(MxdConfigModel):
    schema_name: Annotated[str, Field(alias="$schema")]
    validation_profiles: Annotated[list[str], Field()]


class MxdAnnouncement(Profile):
    repository_identifier: Annotated[None | str, Field()]
    repository_revision: Annotated[None | int, Field()] = None
    repository_revision_datetime: Annotated[None | datetime.datetime, Field()] = None

    mxd_identifier: Annotated[None | str, Field()]
    additional_identifiers: Annotated[None | list[KeyValue], Field()] = None
    dataset_license: Annotated[None | CvTerm, Field()]
    title: Annotated[None | str, Field()]
    description: Annotated[None | str, Field()]
    submission_date: None | datetime.datetime
    public_release_date: None | datetime.datetime

    mxd_metadata_file_uri: Annotated[None | CvTermValue, Field()]

    submitter_keywords: Annotated[None | list[CvTerm], Field()]
    repository_keywords: Annotated[None | list[CvTerm], Field()]

    publications: Annotated[None | list[MxdAnnouncementPublication], Field()]
    submitters: Annotated[list[MxdAnnouncementContact], Field()]
    principal_investigators: Annotated[list[MxdAnnouncementContact], Field()]

    disease: Annotated[None | list[CvTerm], Field()]
    organism: Annotated[None | list[CvTerm], Field()]
    organism_part: Annotated[None | list[CvTerm], Field()]
    instrument: Annotated[None | list[CvTerm], Field()]

    measurement_methodology: Annotated[None | list[CvTerm], Field()] = (
        None  # Targeted metabolite profiling, Untargeted metabolite profiling, ...
    )
    technology_type: Annotated[None | list[CvTerm], Field()]  # NMR, MS, ...
    analysis_type: Annotated[None | list[CvTerm], Field()]  # LC-MS, GC-MS, ...

    full_dataset_uri_list: Annotated[None | list[CvTermValue], Field()]

    # repository_metadata_file_uri_list: Annotated[
    #     None | list[MxdAnnouncedDataFile], Field()
    # ]
    raw_data_file_uri_list: Annotated[None | list[MxdAnnouncedDataFile], Field()]
    # result_file_uri_list: Annotated[None | list[MxdAnnouncedDataFile], Field()]

    reported_metabolites: Annotated[None | list[MxdReportedMetabolite], Field()]
