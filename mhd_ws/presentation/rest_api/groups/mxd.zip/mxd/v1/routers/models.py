import datetime
from typing import Generic, TypeVar

from mxd.presentation.rest_api.groups.mxd.v1.model.mxd import DatasetRevisionStatus
from pydantic import BaseModel, field_serializer, field_validator

T = TypeVar("T")


class DatasetRevisionError(Exception): ...


class TaskResult(BaseModel, Generic[T]):
    success: bool = False
    message: None | str = None
    result: None | T = None


class CreateDatasetRevisionModel(BaseModel):
    accession: None | str = None
    revision: None | int = None
    revision_datetime: datetime.datetime | None = None
    description: None | str = None
    repository_revision: int | None = None
    repository_revision_datetime: datetime.datetime | None = None
    status: None | DatasetRevisionStatus = None

    @field_validator("status")
    @classmethod
    def status_validator(cls, value):
        if value is None:
            return DatasetRevisionStatus.INVALID
        if isinstance(value, int):
            return DatasetRevisionStatus(value)
        if isinstance(value, DatasetRevisionStatus):
            return value
        elif isinstance(value, str):
            return DatasetRevisionStatus[value]
        return DatasetRevisionStatus.INVALID

    @field_serializer("status")
    @classmethod
    def status_serializer(cls, value):
        if value is None:
            return ""
        if isinstance(value, DatasetRevisionStatus):
            return value.name
        return value


class DatasetRevisionModel(BaseModel):
    id: int
    dataset_id: int
    revision: int
    revision_datetime: datetime.datetime | None = None
    task_id: str
    status: DatasetRevisionStatus
    description: str
    created_at: datetime.datetime | None = None
    file_id: int
    repository_revision: int | None = None
    repository_revision_datetime: str | None = None
    updated_at: datetime.datetime | None = None
