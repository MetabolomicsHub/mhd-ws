from logging import getLogger
from typing import Annotated, List

from dependency_injector.wiring import inject
from fastapi import APIRouter
from metabolights_utils.common import CamelCaseModel
from pydantic import Field

logger = getLogger(__name__)

router = APIRouter(tags=["About API"], prefix="/v1/pre-alpha")


class DatasetModel(CamelCaseModel):
    name: Annotated[
        str, Field(title="Dataset Model Name", description="Dataset model name")
    ]
    uri: Annotated[
        str, Field(title="Dataset Model URI", description="Dataset model URI")
    ]
    version: Annotated[
        str, Field(title="Dataset Model Version", description="Dataset model version")
    ]


class MxdServerInfo(CamelCaseModel):
    version: Annotated[str, Field(title="Server Version", description="Server version")]
    supported_profiles: Annotated[
        List[DatasetModel],
        Field(title="Supported Profiles", description="Supported profiles."),
    ]


@router.get(
    "/server-info",
    summary="MetabolomeXchange Server Information",
    description="Show information about MetabolomeXchange server.",
    response_model=MxdServerInfo,
)
@inject
async def get_server_info():
    return MxdServerInfo(
        version="0.0.1",
        supported_profiles=[
            DatasetModel(
                name="mxd-anouncement-file",
                version="0.0.1",
                uri="http://www.metabolomexchange.org/datasets/v0.0.1/mxd-anouncement-file",
            )
        ],
    )
