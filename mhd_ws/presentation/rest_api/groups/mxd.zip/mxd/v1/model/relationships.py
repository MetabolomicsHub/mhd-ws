from pydantic import Field
from typing_extensions import Annotated

from mxd.presentation.rest_api.groups.mxd.v1.model.base import BaseMxdRelationship


class MxdRelationship(BaseMxdRelationship):
    type_: Annotated[str, Field(frozen=True, alias="type")] = "relationship"
