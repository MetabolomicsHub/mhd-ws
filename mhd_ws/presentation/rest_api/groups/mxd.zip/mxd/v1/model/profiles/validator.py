# import json
import asyncio
import json
import pathlib
import re
from ftplib import FTP
from typing import Any, Coroutine, Generic, OrderedDict, TypeVar
from urllib.parse import quote, urlparse

import bioregistry
import httpx
import jsonpath_ng.ext as jp
import jsonschema
import reachable
import reachable.client
from pydantic import BaseModel, ConfigDict, ValidationError, field_validator
from pydantic.alias_generators import to_camel, to_pascal

from mxd.presentation.rest_api.groups.mxd.v1.model.announcement import (
    MxdAnnouncement,
    Profile,
)
from mxd.presentation.rest_api.groups.mxd.v1.model.base import CvTerm
from mxd.presentation.rest_api.groups.mxd.v1.model.controlled_cv import (
    CONTROLLED_CV_DEFINITIONS,
)
from mxd.presentation.rest_api.groups.mxd.v1.model.profiles.announcement_profile import (
    AccessibleCompactURI,
    AccessibleURI,
    AllowAnyCvTerm,
    AllowedChildrenCvTerms,
    AllowedCvList,
    AllowedCvTerms,
    AnnouncementProfile,
    CvTermDefinition,
    CvTermValueDefinition,
    ParentCvTerm,
    ProfileValidation,
    ProfileValidationList,
    RegexValidation,
)
from mxd.presentation.rest_api.groups.mxd.v1.routers.tasks import (
    load_json,
)

P = TypeVar("P", bound=Profile)

CHILDREN_MAP: dict[tuple[str, str], dict[str, CvTermDefinition]] = {}

# ftp_connection_pool: dict[str, FTP] = {}

# client = reachable.client.Client()


class OlsBaseModel(BaseModel):
    """Base model class to convert python attributes to camel case"""

    model_config = ConfigDict(
        populate_by_name=True,
        alias_generator=to_camel,
        JSON_schema_serialization_defaults_required=True,
        field_title_generator=lambda field_name, field_info: to_pascal(
            field_name.replace("_", " ").strip()
        ),
    )


T = TypeVar("T")


class OlsSearchModel(OlsBaseModel, Generic[T]):
    page: int
    num_elements: int
    total_pages: int
    total_elements: int
    elements: list[T]


class ChildrenSearchModel(OlsBaseModel):
    curie: str
    has_hierarchical_children: bool
    has_direct_children: bool
    iri: str
    is_obsolete: bool
    label: str
    ontology_preferred_prefix: str

    @field_validator("label", mode="before")
    @classmethod
    def label_validator(cls, value) -> str:
        if value is None:
            return ""
        if isinstance(value, list):
            return value[0] if value else ""
        return str(value)


class CvTermHelper:
    def save_children(
        self, parent: ParentCvTerm, children: dict[str, CvTermDefinition]
    ):
        file_path = self.get_children_cache_file_path(parent)
        children_dict = {x: y.model_dump() for x, y in children.items()}
        with file_path.open("w") as f:
            f.write(
                json.dumps(
                    {
                        "parent": parent.model_dump(),
                        "children": children_dict,
                    },
                    indent=2,
                )
            )

    def get_children_cache_file_path(self, parent: ParentCvTerm):
        parent_path = pathlib.Path("cache")
        parent_option = "p" if parent.allow_parent else "_"
        leaf_option = "l" if parent.allow_parent else "_"
        name_prefix = (
            parent.cv_term.accession.replace(":", "_") if parent.cv_term else ""
        )
        file_path = parent_path / pathlib.Path(
            f"{name_prefix}_children_{parent_option}_{leaf_option}.json"
        )
        return file_path

    def load_children(self, parent: ParentCvTerm) -> None | dict[str, CvTermDefinition]:
        file_path = self.get_children_cache_file_path(parent)
        if not file_path.exists():
            return None
        try:
            with file_path.open() as f:
                data = json.load(f)
            object_map = {
                x: CvTermDefinition.model_validate(y)
                for x, y in data["children"].items()
            }
            key = (parent.cv_term.source, parent.cv_term.accession)
            if key in CHILDREN_MAP:
                CHILDREN_MAP[key] = object_map
            return object_map
        except Exception as ex:
            print(str(ex))
            return None

    async def get_children_of_cv_term(
        self, parent: ParentCvTerm
    ) -> dict[str, CvTermDefinition]:
        key = (parent.cv_term.source, parent.cv_term.accession)
        if key in CHILDREN_MAP:
            return CHILDREN_MAP[key]

        children_map = self.load_children(parent)
        if children_map is not None:
            return children_map

        children: list[ChildrenSearchModel] = []
        if parent.allow_parent:
            uri = self.get_uri(parent.cv_term)
            children.append(
                ChildrenSearchModel(
                    curie=parent.cv_term.accession,
                    has_direct_children=True,
                    has_hierarchical_children=True,
                    iri=uri,
                    label=parent.cv_term.name,
                    ontology_preferred_prefix=parent.cv_term.source,
                    is_obsolete=False,
                )
            )
        excluded_cv_accessions = set()
        if parent.excluded_cv_terms:
            excluded_cv_accessions = {x.accession for x in parent.excluded_cv_terms}
        await self.get_children(
            parent.cv_term,
            children,
            parent.allow_only_leaf,
            excluded_cv_accessions,
        )
        children.sort(key=lambda x: x.label)
        children_cv_terms = {
            x.curie: CvTermDefinition(
                accession=x.curie, source=x.ontology_preferred_prefix, name=x.label
            )
            for x in children
        }
        CHILDREN_MAP[key] = children_cv_terms
        self.save_children(parent, children_cv_terms)
        return children_cv_terms

    async def get_children(
        self,
        cv_term: CvTermDefinition,
        children: list[ChildrenSearchModel],
        allow_only_leaf: bool = True,
        excluded_cv_accessions: None | set[str] = None,
    ):
        parent_uri = self.get_uri(cv_term)

        parent_uri_encoded = quote(quote(parent_uri, safe=[]))
        children_subpath = f"/ontologies/{cv_term.source.lower()}/classes/{parent_uri_encoded}/children"
        ols4_base_url = "https://www.ebi.ac.uk/ols4/api/v2"

        url = ols4_base_url + children_subpath
        page = 0
        finished = False
        # print(url)
        headers = {"Accept": "application/json"}
        selected_terms = []
        while not finished:
            params = {"page": page, "size": 100}
            page += 1
            result = httpx.get(url, params=params, headers=headers)
            result_json = result.json()
            search = OlsSearchModel[ChildrenSearchModel].model_validate(result_json)
            if not excluded_cv_accessions:
                excluded_cv_accessions = set()
            selected = [
                x
                for x in search.elements
                if not x.is_obsolete and x.curie not in excluded_cv_accessions
            ]
            selected_terms.extend(selected)
            if page >= search.total_pages:
                finished = True
        for term in selected_terms:
            if not allow_only_leaf or (
                allow_only_leaf and not term.has_hierarchical_children
            ):
                children.append(term)

            if term.has_hierarchical_children:
                await self.get_children(
                    cv_term=CvTermDefinition(
                        accession=term.curie,
                        name=term.label,
                        source=term.ontology_preferred_prefix,
                    ),
                    children=children,
                    allow_only_leaf=allow_only_leaf,
                    excluded_cv_accessions=excluded_cv_accessions,
                )

    def get_uri_with_custom_convertor(self, cv_term: CvTermDefinition):
        source = cv_term.source
        cv_definition = CONTROLLED_CV_DEFINITIONS.get(source)
        parent_uri = None
        accession = cv_term.source

        if cv_definition:
            accession = cv_term.accession
            if not accession:
                return ""
            if accession.startswith(cv_definition.prefix):
                parent_uri = accession
            elif ":" in accession:
                parent_uri = cv_definition.prefix + accession.split(":")[1]
            else:
                parent_uri = cv_definition.prefix + accession
        else:
            raise ValueError(f"{source} CV source not found.")
        return parent_uri
        # search.page

    def get_uri(self, cv_term: CvTermDefinition):
        uri = bioregistry.get_default_iri(*cv_term.accession.split(":"))

        if not uri:
            return self.get_uri_with_custom_convertor(cv_term)
        return uri

    # return parent_uri
    async def check_cv_term(
        self, cv_term: CvTermDefinition, parent_cv_term: None | ParentCvTerm = None
    ):
        children_subpath = "/search"

        params = {
            "q": cv_term.accession,
            "ontology": cv_term.source,
            "type": "class,property",
            "queryFields": "obo_id",
            "fieldList": "iri,obo_id,label,short_form",
            "exact": True,
            "format": "json",
            "start": 0,
            "rows": 1,
            "local": False,
            "obsoletes": False,
            "lang": "en",
            "isLeaf": True
            if parent_cv_term and parent_cv_term.allow_only_leaf
            else False,
        }
        ols4_base_url = "https://www.ebi.ac.uk/ols4/api"
        url = ols4_base_url + children_subpath
        if parent_cv_term:
            parent_uri = self.get_uri(parent_cv_term.cv_term)
            params["allChildrenOf"] = parent_uri
            print(
                f"{url}: {cv_term.accession} in {cv_term.source}, parent '{parent_uri}'"
            )
        else:
            print(f"{url}: {cv_term.accession} in {cv_term.source}.")

        headers = {"Accept": "application/json"}
        try:
            result = httpx.get(url, params=params, headers=headers)
            if result.status_code == 404:
                return False, f"{cv_term.accession} is not in ontology {cv_term.source}"
            result.raise_for_status()
            result_json = result.json()
            if result_json.get("response"):
                docs = result_json.get("response").get("docs")
                if docs and docs[0]["obo_id"] == cv_term.accession:
                    return True, None
                else:
                    return False, f"{cv_term.accession} does not match"
            else:
                False, f"{cv_term.accession} does not match"
            search = ChildrenSearchModel.model_validate(result_json)
            if search.curie == cv_term.accession:
                if search.is_obsolete:
                    return (
                        False,
                        f"{cv_term.accession} is obsolete in {cv_term.source} ontology.",
                    )
                return True, None
            return False, f"{cv_term.accession} does not match"
        except httpx.HTTPStatusError as ex:
            return False, f"{cv_term.accession} search failed."
        except Exception as ex:
            return False, f"{cv_term.accession} is not in {cv_term.source} ontology"


class ValidationResult(BaseModel):
    name: str
    root: bool = False
    message: None | str
    valid: bool = False
    data: None | Any = None


class ProfileValidator:
    def get_profile_validation(self) -> type[ProfileValidation]:
        return ProfileValidation

    async def validate(
        self,
        validations: dict[str, list[ValidationResult]],
        path: list[str | int],
        value: Any,
        profile_validation: dict[str, Any],
        child_validator: bool = True,
    ) -> bool:
        if isinstance(profile_validation, dict):
            validation = self.get_profile_validation().model_validate(
                profile_validation
            )
        else:
            validation = profile_validation
        evaluated_value, message = await self.evaluate(
            validations, path, value, validation
        )
        path_str = ".".join([x if isinstance(x, str) else f"[{x}]" for x in path])
        # path_str = path_str.replace(".[", "[")
        valid = not evaluated_value if validation.negate else evaluated_value
        if path_str not in validations:
            validations[path_str] = []
        if child_validator:
            data = value
            if isinstance(value, BaseModel):
                data = value.model_dump()
            validations[path_str].append(
                ValidationResult(
                    name=validation.name, valid=valid, message=message, data=data
                )
            )
        else:
            validations[path_str].append(
                ValidationResult(
                    name=validation.name,
                    root=True,
                    valid=valid,
                    message=message,
                    data=value,
                )
            )
        if valid and not child_validator and path_str in validations:
            del validations[path_str]
        return valid

    async def evaluate(
        self,
        validations: dict[str, list[ValidationResult]],
        field_path: list[str | int],
        value: Any,
        profile_validation: ProfileValidation,
    ) -> tuple[bool, None | str]:
        return False, None


class AllowedCvTermValidator(ProfileValidator):
    def __init__(self, cv_helper: CvTermHelper) -> None:
        self.cv_helper = cv_helper

    def get_profile_validation(self) -> type[AllowedCvTerms]:
        return AllowedCvTerms

    async def evaluate(
        self,
        validations: dict[str, list[ValidationResult]],
        field_path: list[str | int],
        value: Any,
        profile_validation: ProfileValidation,
    ) -> tuple[bool, None | str]:
        valid = False
        val: CvTerm = value
        validator: AllowedCvTerms = profile_validation
        terms = ", ".join(
            [f"[{x.source}, {x.accession}, {x.name}]" for x in validator.cv_terms]
        )
        message = f"[{val.source}, {val.accession}, {val.name}] does not match any allowed CV term. Allowed CV terms: {terms}"
        for term in validator.cv_terms:
            if (
                val.name == term.name
                and val.accession == term.accession
                and val.source == term.source
            ):
                message = None
                valid = True
                break

        return valid, message


class RegexValidator(ProfileValidator):
    def get_profile_validation(self) -> type[RegexValidation]:
        return RegexValidation

    async def evaluate(
        self,
        validations: dict[str, list[ValidationResult]],
        field_path: list[str | int],
        value: Any,
        profile_validation: ProfileValidation,
    ) -> tuple[bool, None | str]:
        validator: RegexValidation = profile_validation
        if validator.allow_null_value and value is None:
            return True, None
        match = re.match(validator.pattern, value)
        if match:
            return True, None
        return False, f"{value} does not match the pattern '{validator.pattern}'"


class AllowAnyCvTermValidator(ProfileValidator):
    def __init__(self, cv_helper: CvTermHelper) -> None:
        self.cv_helper = cv_helper

    def get_profile_validation(self) -> type[AllowAnyCvTerm]:
        return AllowAnyCvTerm

    async def evaluate(
        self,
        validations: dict[str, list[ValidationResult]],
        field_path: list[str | int],
        value: Any,
        profile_validation: ProfileValidation,
    ) -> tuple[bool, None | str]:
        if isinstance(value, CvTermDefinition):
            valid = value.name and value.accession and value.source
            if valid:
                return True, None
            return (
                False,
                f"[{value.name}, {value.accession}, {value.name}] is not valid CV term",
            )
        return False, f"{value} is not an valid CV term"


class ProfileValidationListValidator(ProfileValidator):
    def __init__(
        self,
        validators: dict[str, ProfileValidator],
        ftp_client_pool: dict[str, FTP],
        url_client: reachable.client.Client,
    ) -> None:
        self.ftp_client_pool = ftp_client_pool
        self.url_client = url_client
        self.validators = validators

    def get_profile_validation(self) -> type[ProfileValidationList]:
        return ProfileValidationList

    async def evaluate(
        self,
        validations: dict[str, list[ValidationResult]],
        field_path: list[int | str],
        value: Any,
        profile_validation: ProfileValidation,
    ) -> tuple[bool, None | str]:
        profile_validation_list: ProfileValidationList = profile_validation
        invalid_results = []

        for control in profile_validation_list.controls:
            if isinstance(value, list):
                list_invalid_results = []
                for idx, item in enumerate(value):
                    item_path = field_path.copy()
                    item_path.append(idx)
                    valid = await self.validators[control.name].validate(
                        item_path, item, control
                    )
                    if not valid:
                        list_invalid_results.append((item_path, value))
                if list_invalid_results:
                    invalid_results.append((control.name, list_invalid_results))
                elif (
                    profile_validation_list.join_operator == "or"
                    and not list_invalid_results
                ):
                    break
            else:
                valid = await self.validators[control.name].validate(
                    validations, field_path, value, control
                )

                if not valid:
                    invalid_results.append((control.name, field_path, value))
                elif profile_validation_list.join_operator == "or" and valid:
                    break

        valid = False
        valid_controls = len(profile_validation_list.controls) - len(invalid_results)

        if profile_validation_list.join_operator == "or":
            if valid_controls > 0:
                valid = True
        else:
            if valid_controls == len(profile_validation_list.controls):
                valid = True
        if valid:
            return valid, None
        return False, f"{value} is not validated after evaluation of multiple results."


class AllowedChildrenCvTermsValidator(ProfileValidator):
    def __init__(self, cv_helper: CvTermHelper) -> None:
        self.cv_helper = cv_helper

    def get_profile_validation(self) -> type[AllowedChildrenCvTerms]:
        return AllowedChildrenCvTerms

    async def evaluate(
        self,
        validations: dict[str, list[ValidationResult]],
        field_path: list[str | int],
        value: Any,
        profile_validation: ProfileValidation,
    ) -> tuple[bool, None | str]:
        if not isinstance(profile_validation, AllowedChildrenCvTerms):
            return False, "Invalid validator"

        validator: AllowedChildrenCvTerms = profile_validation

        parents = ", ".join(
            [
                f"[{x.cv_term.source}, {x.cv_term.accession}, {x.cv_term.name}]"
                for x in validator.parent_cv_terms
            ]
        )
        cv_term: CvTermDefinition = value
        if not isinstance(value, CvTermDefinition):
            return False, "input is not Cv term"
        valid = False
        for parent in validator.parent_cv_terms:
            if parent.index_cv_terms:
                terms = await self.cv_helper.get_children_of_cv_term(parent)
                if cv_term.accession in terms:
                    valid = True
                    return valid, None
            else:
                search_result, message = await self.cv_helper.check_cv_term(
                    cv_term=value, parent_cv_term=parent
                )
                if search_result:
                    return search_result, message

        message = (
            f"[{cv_term.source}, {cv_term.accession}, {cv_term.name}] is not child of allowed CV terms. "
            f"Terms should be child of any {parents} CV terms"
        )
        return valid, message


class AllowedCvListValidator(ProfileValidator):
    def __init__(self, cv_helper: CvTermHelper) -> None:
        self.cv_helper = cv_helper

    def get_profile_validation(self) -> type[AllowedCvList]:
        return AllowedCvList

    async def evaluate(
        self,
        validations: dict[str, list[ValidationResult]],
        field_path: list[str | int],
        value: Any,
        profile_validation: ProfileValidation,
    ) -> tuple[bool, None | str]:
        if not isinstance(profile_validation, AllowedCvList):
            return False, "Invalid validator"
        validation: AllowedCvList = profile_validation
        valid = False

        if value.source in validation.source_names:
            check_valid, message = await self.cv_helper.check_cv_term(value)
            return check_valid, message

            # message = f"[{value.source}, {value.accession}, {value.name}] is not found in {value.source} CV source."
            # return True, message
        else:
            labels = ", ".join(validation.source_names)
            message = (
                f"[{value.source}, {value.accession}, {value.name}] is not in any allowed CV source. "
                f"Define a CV term from the selected CV sources: {labels}"
            )

        return valid, message


class AccessibleURIValidator(ProfileValidator):
    def __init__(
        self, ftp_client_pool: dict[str, FTP], url_client: reachable.client.Client
    ) -> None:
        self.ftp_client_pool = ftp_client_pool
        self.url_client = url_client

    def get_profile_validation(self) -> type[AccessibleURI]:
        return AccessibleURI

    async def evaluate(
        self,
        validations: dict[str, list[ValidationResult]],
        field_path: list[str | int],
        value: Any,
        profile_validation: ProfileValidation,
    ) -> tuple[bool, None | str]:
        # validation: AccessibleURI = profile_validation
        # valid = False

        try:
            data: CvTermValueDefinition = CvTermValueDefinition.model_validate(value)
            if not data.value:
                return False, f"URL does not exist: {data.value}"
            if not isinstance(data.value, str):
                return False, f"Value type is not string: {data.value}"
            url: str = data.value
            uri = urlparse(url=url)
            if uri.scheme in ("http", "https"):
                # url = data.value.replace("ftp://", "https://")
                # url = "https://www.metabolomicsworkbench.org/data/study_textformat_view.php?JSON=YES&STUDY_ID=ST003sss525&ANALYSIS_ID=AN00578sss8&MODE=d"
                # print(".", end="")
                result = reachable.is_reachable(url, client=self.url_client)
                if isinstance(result, list):
                    result = result[0] if result[0] else {}
                # result = httpx.head(value, follow_redirects=True, timeout=60)
                # reachable = await is_reachable_async(url)
                if result.get("success"):
                    print(f"Accessible URI: {url}")
                    return True, f"Accessible URI: {url}"
                else:
                    print(f"URL does not exist: {url}")
                    return False, f"URL does not exist: {url}"

                # if result.status_code == 404:
                #     print(f"URL does not exist: {value}")
                #     return False, f"URL does not exist: {value}"
                # result.raise_for_status()
                # if reachable and reachable.get("success"):
                #     print("Reachable:", url)
                # print(f"Accessible URI: {data.value}")

                # return True, None
            # print("Not Reachable:", url)
            # return False, reachable.get("error_name")
            elif uri.scheme in ("ftp", "ftp"):
                if uri.hostname not in self.ftp_client_pool:
                    ftp = FTP(user="", host=uri.hostname, timeout=30)
                    ftp.login()
                    if uri.hostname not in self.ftp_client_pool:
                        self.ftp_client_pool[uri.hostname] = ftp
                ftp = self.ftp_client_pool[uri.hostname]
                # ftp.cwd(str(full_path.parent))
                try:
                    # ftp.login()
                    full_path = pathlib.Path(uri.path)
                    ftp.size(str(full_path))

                except Exception as ex:
                    # print(f"Target file is not accessible: {url}")
                    return False, f"Target file is not accessible: {url}"

                    # print("file does not exist or error")

                # ftp.cwd(full_path.parent)
                # result = ftp.retrlines("LIST")
                # print(result)
                # with ftputil.FTPHost(uri.netloc, "", "", timeout=3) as host:
                #     # names = host.listdir(str(full_path.parent))
                #     # for name in names:
                #     if host.path.isfile(str(full_path)) or host.path.isdir(
                #         str(full_path)
                #     ):
                #         # Remote name, local name
                #         # host.download(name, name)
                #         return True, None
                #     else:
                # print(f"Target file does not exist: {data.value}")
                # return False, f"Target file does not exist: {data.value}"
                return True, None
            return False, f"Unsupported protocol {url}"
        except Exception as ex:
            print(f"Unaccessible URI: {value}", str(ex))
            return False, f"Unaccessible URI: {value}"


class AccessibleCompactURIValidator(ProfileValidator):
    def __init__(
        self, ftp_client_pool: dict[str, FTP], url_client: reachable.client.Client
    ) -> None:
        self.ftp_client_pool = ftp_client_pool
        self.url_client = url_client

    def get_profile_validation(self) -> type[AccessibleCompactURI]:
        return AccessibleCompactURI

    async def evaluate(
        self,
        validations: dict[str, list[ValidationResult]],
        field_path: list[str | int],
        value: Any,
        profile_validation: ProfileValidation,
    ) -> tuple[bool, None | str]:
        if not isinstance(profile_validation, AccessibleCompactURI):
            return False, "Invalid validator"
        validator: AccessibleCompactURI = profile_validation
        if not value:
            if validator.allow_null_value:
                return True, None
            return False, "Value is not defined"
        if not validator.default_prefix:
            return False, f"Unaccessible URI: {validator.default_prefix}"
        identifier = value.replace(f"{validator.default_prefix}:", "")
        default_uri = bioregistry.get_default_iri(validator.default_prefix, identifier)

        if not default_uri:
            return False, f"Invalid URI: {default_uri}"
        headers = {
            "Accept": "*/*",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
            "Cache-Control": "no-cache",
            "User-Agent": "PostmanRuntime/7.43.3",
            "Authorization": "",
        }
        try:
            # result = httpx.get(
            #     default_uri,
            #     headers=headers,
            #     follow_redirects=validator.follow_redirects,
            #     timeout=60,
            # )
            url: str = default_uri
            result = reachable.is_reachable(
                url, headers=headers, client=self.url_client
            )
            if isinstance(result, list):
                result = result[0] if result[0] else {}
            # reachable = await is_reachable_async(url)
            # if not validator.follow_redirects:
            #     if result.status_code == 302:
            #         print(f"URL is redirected: {default_uri}")
            #         return True, f"URL is redirected: {default_uri}"

            if result.get("success"):
                return True, f"Accessible URI: {default_uri}"
            else:
                print(f"URL does not exist: {default_uri}")
                return False, f"URL does not exist: {default_uri}"
        except Exception as ex:
            print(f"Unaccessible URI: {default_uri}", str(ex))
            return False, f"Unaccessible URI: {default_uri}"

    # asyncio.gather(*tasks_list)
    # async for task in asyncio.as_completed(tasks_list):
    #     print(task.result())
    # print("result")


with pathlib.Path("resources/mxd/announcement-v0.1.schema.json").open("w") as f:
    json.dump(MxdAnnouncement.model_json_schema(), f, indent=2)

with pathlib.Path("resources/mxd/announcement-v0.1.schema.ms-profile.json").open(
    "w"
) as f:
    json.dump(AnnouncementProfile.model_json_schema(), f, indent=2)


class ProfileValidationManager:
    def __init__(
        self,
        supported_schemas: dict[str, tuple[str, type[Profile]]],
        default_schema: str,
        supported_profiles: dict[str, tuple[str, type[Profile]]],
    ) -> None:
        self.supported_profiles = supported_profiles
        self.supported_schemas = supported_schemas
        self.default_schema = default_schema
        ftp_client_pool: dict[str, FTP] = {}
        url_client: reachable.client.Client = reachable.client.Client()
        self.cv_helper = CvTermHelper()

        self.validators: dict[str, ProfileValidator] = {
            "regex-validation": RegexValidator(),
            "allowed-cv-terms": AllowedCvTermValidator(self.cv_helper),
            "allowed-children-cv-terms": AllowedChildrenCvTermsValidator(
                self.cv_helper
            ),
            "allow-any-cv-term": AllowAnyCvTermValidator(self.cv_helper),
            "allowed-cv-list": AllowedCvListValidator(self.cv_helper),
            "accessible-uri": AccessibleURIValidator(
                ftp_client_pool=ftp_client_pool, url_client=url_client
            ),
            "accessible-compact-uri": AccessibleCompactURIValidator(
                ftp_client_pool=ftp_client_pool, url_client=url_client
            ),
        }
        self.validators["validation-list"] = ProfileValidationListValidator(
            validators=self.validators,
            ftp_client_pool=ftp_client_pool,
            url_client=url_client,
        )

    def validate_schema(
        self,
        json_data: dict[str, Any],
        schema: dict[str, Any],
        validations: dict[str, list[ValidationResult]],
    ):
        validator = jsonschema.Draft202012Validator(schema)

        errors = validator.iter_errors(json_data)
        for error in errors:
            path_str = ".".join(
                [x if isinstance(x, str) else f"[{x}]" for x in error.path]
            )
            if path_str not in validations:
                validations[path_str] = []
            validations[path_str].append(
                ValidationResult(
                    name=str(error.validator),
                    root=True,
                    message=error.message,
                    data=error.instance,
                )
            )
            path_str = path_str if path_str else "$"
            expression = jp.parse(path_str)
            search_results = expression.find(json_data)
            result = [x.value for x in search_results]

    def get_validated_model(
        self,
        model_class: type[Profile],
        json_data: dict[str, Any],
        validations: dict[str, list[ValidationResult]],
    ):
        try:
            return model_class.model_validate(json_data)

        except ValidationError as ex:
            for error in ex.errors():
                path_str = ".".join(
                    [x if isinstance(x, str) else f"[{x}]" for x in error["loc"]]
                )
                if path_str not in validations:
                    validations[path_str] = []
                validations[path_str].append(
                    ValidationResult(
                        name=error["type"],
                        message=error["msg"],
                        root=True,
                        data=error["input"],
                    )
                )
            return None

    async def validate(
        self,
        json_data: dict[str, Any],
    ):
        validations: OrderedDict[str, list[ValidationResult]] = OrderedDict()
        json_schema = json_data.get("$schema")
        if json_schema in self.supported_schemas:
            json_schema_file_path = self.supported_schemas[json_schema][0]
            model_class: type[Profile] = self.supported_schemas[json_schema][1]
        else:
            json_schema_file_path = self.supported_schemas[self.default_schema][0]
            model_class: type[Profile] = self.supported_schemas[self.default_schema][1]

        # schema_file = load_json(json_schema_file_path)
        # self.validate_schema(json_data, schema_file, validations)

        model = self.get_validated_model(model_class, json_data, validations)

        if not model:
            return validations

        for profile in model.validation_profiles:
            if profile in self.supported_profiles:
                profile_file_path = self.supported_profiles[profile][0]
                profile_class = self.supported_profiles[profile][1]
                profile_file = load_json(profile_file_path)

                self.validate_schema(json_data, profile_file, validations)
                profiled_announcement = self.get_validated_model(
                    profile_class, json_data, validations
                )
                if not profiled_announcement:
                    return validations
                profiles = {}
                self.create_profile_file(profiled_announcement, profiles, [])
                with open("resources/mxd/profiles.json", "w") as f:
                    json.dump(profiles, f, indent=2)
                expression = jp.parse("raw_data_file_uri_list.[*].file_uri_list")
                search_results = expression.find(announcement_file_json)
                result = [x.value for x in search_results]
                if not result:
                    print(result)

                if not profiled_announcement:
                    return validations
                tasks = []
                self.validate_model(profiled_announcement, validations, tasks, [])
                # print(len(tasks))
                await self.run_tasks(tasks)
            else:
                raise Exception("Not supported")
        return validations

    def validate_model(
        self,
        model: BaseModel,
        validations: dict[str, list[ValidationResult]],
        tasks: list[Coroutine],
        path: list[str | int],
    ):
        for field_name, field_info in model.__class__.model_fields.items():
            field_path: list[int | str] = path.copy()
            field_path.append(field_name)
            value = getattr(model, field_name)

            if (
                field_info.json_schema_extra
                and isinstance(field_info.json_schema_extra, dict)
                and field_info.json_schema_extra.get("profile_validation")
            ):
                profile_validation = field_info.json_schema_extra.get(
                    "profile_validation"
                )
                if (
                    isinstance(profile_validation, dict)
                    and "name" in profile_validation
                ):
                    validator_name = profile_validation["name"]
                    if validator_name in self.validators:
                        validator = self.validators[validator_name]
                        if isinstance(value, list):
                            # if not isinstance(value[0], BaseModel):
                            for idx, x in enumerate(value):
                                item_path: list[int | str] = field_path.copy()
                                item_path.append(idx)
                                coroutine = validator.validate(
                                    validations,
                                    item_path,
                                    x,
                                    profile_validation,
                                    child_validator=False,
                                )
                                tasks.append(coroutine)
                                # if not validated:
                                #     validations.append((field_path, x))
                        else:
                            coroutine = validator.validate(
                                validations,
                                field_path,
                                value,
                                profile_validation,
                                child_validator=False,
                            )
                            tasks.append(coroutine)
                            # if not validated:
                            #     validations.append((field_path, value))
                    else:
                        raise ValidationError("Not valid validation name")
                else:
                    raise ValidationError("Not valid")

            if isinstance(value, BaseModel):
                self.validate_model(value, validations, tasks, field_path)
            elif isinstance(value, list) and value and isinstance(value[0], BaseModel):
                for idx, x in enumerate(value):
                    item_path: list[int | str] = field_path.copy()
                    item_path.append(idx)
                    self.validate_model(x, validations, tasks, item_path)

    def create_profile_file(
        self,
        model: BaseModel,
        profiles: dict[str, Any],
        path: list[str | int],
    ):
        for field_name, field_info in model.__class__.model_fields.items():
            field_path: list[int | str] = path.copy()
            field_path.append(field_name)
            value = getattr(model, field_name)

            if (
                field_info.json_schema_extra
                and isinstance(field_info.json_schema_extra, dict)
                and field_info.json_schema_extra.get("profile_validation")
            ):
                profile_validation = field_info.json_schema_extra.get(
                    "profile_validation"
                )
                if (
                    isinstance(profile_validation, dict)
                    and "name" in profile_validation
                ):
                    validator_name = profile_validation["name"]
                    if validator_name in self.validators:
                        validator = self.validators[validator_name]
                        profile = validator.get_profile_validation().model_validate(
                            profile_validation
                        )
                        path_str = ".".join(
                            [x if isinstance(x, str) else "[*]" for x in field_path]
                        )
                        # path_str = path_str.removesuffix(".[*]")
                        if path_str not in profiles:
                            profiles[path_str] = profile.model_dump()
                    else:
                        raise ValidationError("Not valid validation name")
                else:
                    raise ValidationError("Not valid")

            if isinstance(value, BaseModel):
                self.create_profile_file(value, profiles, field_path)
            elif isinstance(value, list) and value and isinstance(value[0], BaseModel):
                for idx, x in enumerate(value):
                    item_path: list[int | str] = field_path.copy()
                    item_path.append(idx)
                    self.create_profile_file(x, profiles, item_path)

    async def run_tasks(self, tasks):
        tasks_list = []

        for task in tasks:
            task_ins = asyncio.create_task(task)
            tasks_list.append(task_ins)
            await task_ins


SUPPORTED_ANNOUNCEMENT_PROFILES: dict[str, tuple[str, type[Profile]]] = {
    "https://www.metabolomexchange.org/schemas/v0.1/announcement-v0.1.schema.ms-profile.json": (
        "resources/mxd/announcement-v0.1.schema.ms-profile.json",
        AnnouncementProfile,
    )
}

DEFAULT_SCHEMA = (
    "https://www.metabolomexchange.org/schemas/v0.1/announcement-v0.1.schema.json"
)


SUPPORTED_ANNOUNCEMENTS: dict[str, tuple[str, type[Profile]]] = {
    DEFAULT_SCHEMA: ("resources/mxd/announcement-v0.1.schema.json", MxdAnnouncement)
}

announcement_schema_file_path = SUPPORTED_ANNOUNCEMENTS[DEFAULT_SCHEMA]

announcement_file_json = load_json("MTBLS4381_announcement.json")

validation = ProfileValidationManager(
    supported_schemas=SUPPORTED_ANNOUNCEMENTS,
    supported_profiles=SUPPORTED_ANNOUNCEMENT_PROFILES,
    default_schema=DEFAULT_SCHEMA,
)

validations = asyncio.run(validation.validate(announcement_file_json))


validation_result = {
    x: [ValidationResult.model_dump(y) for y in items]
    for x, items in validations.items()
}
print(json.dumps(validation_result, indent=2))
# expression = jp.parse("publications.[*].title")
# search_results = expression.find(announcement_file_json)
# result = [x.value for x in search_results]
# if not result:
#     print(result)
